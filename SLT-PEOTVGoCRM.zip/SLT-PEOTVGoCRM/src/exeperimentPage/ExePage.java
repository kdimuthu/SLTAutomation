package exeperimentPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class ExePage extends TestBase_Commands {
	private static By btn_Login = By.xpath("//label");

	public ExePage(WebDriver driver) {
		this.driver = driver;
	}

	public void bf_Login() {

		Open("http://test.selfcare.peotv.com/login");
		SelectCheckBox(btn_Login, "Password,Email (Username)");
	//	CheckAlOptions(btn_Login,"Select a package,PEO TV Go 2 Screen,dfdf");
	

		// VerifyMaxLength(btn_Login, 4);
		// EnterRadomNumbers(btn_Login, 12);
		// EnterRadomTextWithPrefix(btn_Login, "Auto", 4);		
		// VerifyCharacterLengh(btn_Login, 7);
		// VerifyText(btn_Login, "tes");
		// StoreInnerHTML(btn_Login);
		// CheckElementPresent(btn_Login,false);
		// VerifyElementIsReadOnly(btn_Login, false);

	}

}
