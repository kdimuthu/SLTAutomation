package exeperimentPage;

import org.testng.Assert;
import org.testng.annotations.Test;
import Utility.ExcelReader;
import Utility.SeleniumTestBase;

public class ExePage_Tests extends SeleniumTestBase {
	ExePage _ExePage;
	

	@Test(priority = 1, enabled = true)
	public void tc_ClickCreateAccountAndVerifyCustomerUI() {
		_ExePage=new ExePage(driver);
		_ExePage.bf_Login();
	}
	
}
