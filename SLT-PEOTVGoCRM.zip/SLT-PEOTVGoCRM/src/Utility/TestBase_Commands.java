package Utility;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

public class TestBase_Commands extends SeleniumTestBase {

	/** Wait for the explicit wait */
	private static WebDriverWait wait;

	/** The web driver. */
	public static WebDriver driver = null;

	/** The time out. */
	private static int timeOut = 10;

	/**
	 * Sets the driver.
	 *
	 * @param driver the new web driver
	 */
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * Gets the driver.
	 *
	 * @return the driver
	 */
	public static WebDriver getDriver() {
		return driver;
	}

	/**
	 * Launch the application.
	 *
	 * @param url-> the url
	 */
	public void Open(String url) {

		try {
			getDriver().navigate().to(url);
			logs.log(Status.INFO, "Opened the browser [" + url + "] successfully");
		} catch (Exception e) {
			logs.log(Status.ERROR,
					MarkupHelper.createLabel("Fail to open the brower due to " + e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Type on a web element.
	 *
	 * @param byLocator -> object locator
	 * @param text      -> the text to be typed
	 */

	public void Type(By byLocator, String text) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(text);
			logs.log(Status.INFO, "Typed the text " + text + " in element '" + StoreInnerHTML(byLocator) + "'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Enter a random generated text(characters ) to a input field
	 *
	 * @param byLocator      -> object locator *
	 * @param chacacterCount -> Character count of the text to be entered
	 */

	public void EnterRadomCharacters(By byLocator, int chacacterCount) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// String randomText = UUID.randomUUID().toString();
			String randomText = RandomStringUtils.randomAlphabetic(chacacterCount);
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(randomText);
			logs.log(Status.INFO, "Entered a text as '**" + randomText + "**' with " + chacacterCount
					+ " caracters randomly to element '**" + StoreInnerHTML(byLocator) + "**'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Enter a random generated integers to a input field
	 *
	 * @param byLocator    -> object locator
	 * @param IntegerCount -> Integer count of the text to be entered
	 */

	public void EnterRadomNumbers(By byLocator, int IntegerCount) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String randomIntegers = RandomStringUtils.randomNumeric(IntegerCount);
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(randomIntegers);
			logs.log(Status.INFO, "Entered a text as '**" + randomIntegers + "**' with " + IntegerCount
					+ " integers randomly to element '**" + StoreInnerHTML(byLocator) + "**'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Enter a random generated text(characters ) with a known prefix to a input
	 * field
	 *
	 * @param byLocator      -> object locator *
	 * @param chacacterCount -> Character count of the text to be entered
	 * @param                prefix-> Known text to be entered
	 */

	public void EnterRadomCharactersWithPrefix(By byLocator, String prefix, int chacacterCount) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// String randomText = UUID.randomUUID().toString();
			String randomText = RandomStringUtils.randomAlphabetic(chacacterCount);
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(prefix + randomText);
			logs.log(Status.INFO, "Entered a text as '**" + prefix + randomText + "**' randomly to element '**"
					+ StoreInnerHTML(byLocator) + "**'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Enter a random generated integers with a known prefix to a input field
	 *
	 * @param byLocator   -> object locator
	 * @param byLocator   -> known integers to be entered
	 * @param InegerCount -> Integer count of the text to be entered
	 */

	public void EnterRadomIntegersWithPrefix(By byLocator, String prefix, int InegerCount) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String randomTintegers = RandomStringUtils.randomNumeric(InegerCount);
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(prefix + randomTintegers);
			logs.log(Status.INFO, "Entered a text as '**" + prefix + randomTintegers + "**' randomly to element '**"
					+ StoreInnerHTML(byLocator) + "**'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Click on a web element.
	 *
	 * @param byLocator -> object locator
	 */

	public void Click(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			WebElement element = getDriver().findElement(byLocator);
			element.click();
			logs.log(Status.INFO, "Clicked on the element '" + byLocator + "'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Clear a text on a element
	 *
	 * @param byLocator -> object locator
	 */

	public void Clear(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			WebElement element = getDriver().findElement(byLocator);
			element.clear();
			logs.log(Status.INFO, "Cleare the text on the element '" + StoreInnerHTML(byLocator) + "'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Clear before typing & Type on a element.
	 *
	 * @param byLocator -> object locator
	 * @param text      -> the text to be typed
	 */

	public void ClearAndType(By byLocator, String text) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			WebElement element = getDriver().findElement(byLocator);
			element.clear();
			element.sendKeys(text);
			logs.log(Status.INFO, "Typed the input '" + text + "' in element '" + StoreInnerHTML(byLocator) + "'.");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Click on a Radio Button
	 *
	 * @param byLocator-> the object locator to be clicked
	 */
	public void ClickRadioButton(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			WebElement element = getDriver().findElement(byLocator);
			Actions actions = new Actions(driver);
			actions.moveToElement(element).click().perform();
			logs.log(Status.INFO, "Click on the radio button on element '" + StoreInnerHTML(byLocator) + "'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that radio button is selected or not by default
	 * 
	 * @param byLocator -> object locator*
	 * @param selected  -> radio button selected or not(true or false)
	 */

	public void VerifyRadioButtonSelected(By byLocator, boolean selectedStatus) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			String elementStatus = getDriver().findElement(byLocator).getAttribute("checked");
			if (elementStatus != null && !elementStatus.isEmpty()) {
				if (selectedStatus == true) {
					logs.log(Status.INFO, "Radion button with the object '" + byLocator + "' is selected.");
				} else {

					FailTest("Radion button with the object '" + byLocator
							+ "' should be selected . But actualy it is not selected.");
				}
			} else {
				if (selectedStatus == false) {
					logs.log(Status.INFO, "Radion button with the object '" + byLocator + "' is not selected.");

				} else {
					FailTest("Radion button with the object '" + byLocator
							+ "' should not be selected. But actualy it is selected.");
				}
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify a text or a massage
	 *
	 * @param byLocator       -> object locator
	 * 
	 * @param expectedMessage -> the expectedMessage to be verified
	 */
	public void VerifyText(By byLocator, String expectedMessage) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String ActualtMessage = getDriver().findElement(byLocator).getText();
			String ExpectedMessage = expectedMessage;
			if (ActualtMessage.equals(ExpectedMessage)) {
				logs.log(Status.INFO, "Verification done for the element '" + StoreInnerHTML(byLocator)
						+ "'. & it is showing as ' " + ActualtMessage + " '");
			} else {
				FailTest("Verification fail for the element '" + StoreInnerHTML(byLocator) + "'. Expected **"
						+ ExpectedMessage + "** but found **" + ActualtMessage + "**");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the title of a page
	 *
	 * @param title -> the Expected title of the page
	 * 
	 */

	public void VerifyTitle(String title) {

		try {
			getDriver().manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);
			String actualtTitle = getDriver().getTitle();
			String expectedTitle = title;
			if (actualtTitle.equals(expectedTitle)) {
				logs.log(Status.INFO, "Title Verification done. Actual & Expected titles are same");
			} else {
				FailTest("Verification fail. Expected **" + expectedTitle + "** but found **" + actualtTitle + "**");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the placeholder of an element
	 * 
	 * @param byLocator   -> the object locator
	 * @param placeholder -> placeholder to be verified
	 */
	public void VerifyPlaceHolder(By byLocator, String placeholder) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String ActualtPlaceholder = getDriver().findElement(byLocator).getAttribute("placeholder");
			String ExpectedPlaceholder = placeholder;
			if (ActualtPlaceholder.equals(ExpectedPlaceholder)) {
				logs.log(Status.INFO, "Verification done.Placeholder of element'" + StoreInnerHTML(byLocator)
						+ "' is showing correctly as '**" + ActualtPlaceholder + "**'.");
			} else {
				FailTest("Verification fail. Expected placeholder of element '" + StoreInnerHTML(byLocator) + "' is '**"
						+ ExpectedPlaceholder + "**' but found '**" + ActualtPlaceholder + "**'.");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that date field display current date by default
	 * 
	 * @param byLocator   -> the object locator	 
	 *  
	 */
	
	public void VerifyElementShowCurrentDate(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String getDate = getDriver().findElement(byLocator).getAttribute("value");
			String CurrentDate = new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());

			if (getDate.equals(CurrentDate)) {
				logs.log(Status.INFO,
						"Date field '" + StoreInnerHTML(byLocator) + "' is showing current date ' "+CurrentDate +" ' as default date");
			} else {
				FailTest("Verification fail. Expected current date ' " + CurrentDate
						+ " ' by default, but showing the date " + getDate + " ' for date " + StoreInnerHTML(byLocator)
						+ " ' field");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}
	
	/**
	 * Verify that date field display current date by default
	 * 
	 * @param byLocator   -> the object locator	 
	 * @param date   -> expected date to be verified
	 * 
	 */
	
	public void VerifyDate(By byLocator,String date) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String getDate = getDriver().findElement(byLocator).getAttribute("value");
			String ExpectedDate = date;

			if (getDate.equals(ExpectedDate)) {
				logs.log(Status.INFO,
						"Date field '" + StoreInnerHTML(byLocator) + "' is showing correct date ' "+getDate+" ' by default.");
			} else {
				FailTest("Verification fail. Expected  date ' " + ExpectedDate
						+ " ' by default, but showing the date " + getDate + " ' for date " + StoreInnerHTML(byLocator)
						+ " ' field");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the header message
	 *
	 * @param byLocator       -> object locator
	 * 
	 * @param expectedMessage -> expected header message to be verified
	 */
	public void VerifyHeader(By byLocator, String expectedMessage) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String ActualtHeaderMessage = getDriver().findElement(byLocator).getText();
			String ExpectedHeaderMessage = expectedMessage;
			if (ActualtHeaderMessage.equals(ExpectedHeaderMessage)) {
				logs.log(Status.INFO,
						MarkupHelper.createLabel("Verification pass for the header message. Navigated to '**"
								+ ActualtHeaderMessage + "**' page successfully .", ExtentColor.GREEN));
			} else {
				FailTest("Verification fail. Expected '**" + ExpectedHeaderMessage + "**' but found '**"
						+ ActualtHeaderMessage + "**'.");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the element is presented or not in the page
	 *
	 * @param byLocator     -> object Locator
	 * @param elementStatus -> true or false statue. true -> presented false-> Not
	 *                      presented
	 * 
	 */

	public void CheckElementPresent(By byLocator, boolean elementStatus) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {

			}
			Boolean eleStatus = null;
			if (elementStatus) {
				try {
					eleStatus = getDriver().findElement(byLocator).isDisplayed();
				} catch (NoSuchElementException e) {

				}
				if (eleStatus == null) {
					FailTest("Element '" + StoreInnerHTML(byLocator)
							+ "' should be exist. But found it dosen' exist in the page");
				} else {
					logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' exists in the page");
				}

			} else {
				try {
					eleStatus = getDriver().findElement(byLocator).isDisplayed();
				} catch (NoSuchElementException e) {

				}
				if (eleStatus == null) {
					logs.log(Status.INFO,
							"Element '" + StoreInnerHTML(byLocator) + "' doesn't exists in the page as expected.");
				} else {
					FailTest("Element '" + StoreInnerHTML(byLocator)
							+ "' should not be exist. But found it exist in the page.");
				}
			}

		} catch (Exception e) {

		}
	}

	/**
	 * Verify the element is enabled & editable
	 * 
	 * @param byLocator     -> object Locator
	 * @param elementStatus -> true or false statue. true -> Enabled false-> Not
	 *                      Enabled
	 * 
	 */

	public void CheckElementEnabled(By byLocator, boolean elementStatus) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			List<WebElement> allelements = driver.findElements(byLocator);
			for (WebElement element : allelements) {
				Boolean eleStatus = element.isEnabled();

				if (elementStatus) {
					if (eleStatus) {
						logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' is Enable & Editable");
					} else {
						FailTest("Element '" + StoreInnerHTML(byLocator)
								+ "' should be enabled & editable. But found it is rean only");
					}
				} else {
					if (!eleStatus) {
						logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' is in readonly mode");
					} else {
						FailTest("Element '" + StoreInnerHTML(byLocator)
								+ "' should be in read only mode. But found it is editable");
					}
				}
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the element is selected
	 * 
	 * @param byLocator     -> object Locator
	 * @param elementStatus -> true or false statue. true -> Selected false-> Not
	 *                      Selected
	 * 
	 */
	public void CheckElementSelected(By byLocator, boolean elementStatus) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			List<WebElement> allelements = driver.findElements(byLocator);
			for (WebElement element : allelements) {
				Boolean eleStatus = element.isSelected();

				if (elementStatus) {
					if (eleStatus) {
						logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' is selected");
					} else {
						FailTest("Element '" + StoreInnerHTML(byLocator)
								+ "' should be selected. But found it is not selected");
					}
				} else {
					if (!eleStatus) {
						logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' is not selected");
					} else {
						FailTest("Element '" + StoreInnerHTML(byLocator)
								+ "' should be not selected. But found it is selected");
					}
				}
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Get the status as true or false if the element is visible or not in the page
	 *
	 * @param byLocator-> object locator
	 * 
	 */

	public Boolean IsElementPresent(By byLocator) {

		try {
			wait = new WebDriverWait(getDriver(), timeOut);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
		} catch (TimeoutException e) {
		}
		try {
			Boolean elementStatus = getDriver().findElement(byLocator).isDisplayed();

			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' Exists in the page.");
			}
			return elementStatus;
		} catch (NoSuchElementException e) {

		}
		logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' Doesn't exists in the page");
		return false;
	}

	/**
	 * Get the status of element as true or false , whether element is selected or
	 * not
	 *
	 * @param byLocator-> object locator
	 * 
	 */

	public Boolean IsElementSelected(By byLocator) {

		try {
			wait = new WebDriverWait(getDriver(), timeOut);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
		} catch (TimeoutException e) {
		}
		try {
			Boolean elementStatus = getDriver().findElement(byLocator).isSelected();

			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' is selected in the page.");
			}

			return elementStatus;
		} catch (NoSuchElementException e) {

		}
		logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' Doesn't select in the page.");
		return false;
	}

	/**
	 * Get the status of element true or false , whether element is enabled or not
	 *
	 * @param byLocator -> object locator
	 * 
	 */

	public Boolean IsElementEnabled(By byLocator) {

		try {
			wait = new WebDriverWait(getDriver(), timeOut);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
		} catch (TimeoutException e) {
		}
		try {
			Boolean elementStatus = getDriver().findElement(byLocator).isEnabled();

			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' Enabled in the page.");
			}

			return elementStatus;
		} catch (NoSuchElementException e) {

		}
		logs.log(Status.INFO, "Element '" + StoreInnerHTML(byLocator) + "' Doesn't enabled in the page.");
		return false;
	}

	/**
	 * Verify the property of an element using getAttribute method
	 * 
	 * @param byLocator     -> object locator
	 * @param properyType   -> Expected properyType to be verified
	 * @param propertyValue -> Expected propertyValue to be verified
	 */
	public void VerifyElementProperty(By byLocator, String properyType, String propertyValue) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String ActualtProperty = getDriver().findElement(byLocator).getAttribute(properyType);
			String ExpectedProperty = propertyValue;
			if (ActualtProperty.equals(ExpectedProperty)) {
				logs.log(Status.INFO, "Verification done.'" + properyType + "' Propery of element '"
						+ StoreInnerHTML(byLocator) + "' is showing correctly as '**" + propertyValue + "**'.");
			} else {
				FailTest("Verification fail. Expected value of '" + properyType + "'" + " property is '**"
						+ ExpectedProperty + "**' but found '**" + ActualtProperty + "**'.");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}

	}

	/**
	 * Select a value from drop down using SelectByvisibletext
	 * 
	 * @param byLocator -> object locator
	 * @param value     -> value to be selected
	 */

	public void SelectValueSelectByVisibleText(By byLocator, String value) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			ddValue.selectByVisibleText(value);
			logs.log(Status.INFO, "Selected the option '" + value + "' from the dropdown " + StoreInnerHTML(byLocator));
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Select a value from drop down using Select By Value
	 * 
	 * @param byLocator -> object locator
	 * @param value     -> value to be selected
	 */

	public void SelectValueSelectByValue(By byLocator, String value) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			ddValue.selectByValue(value);
			logs.log(Status.INFO, "Selected the option '" + value + "' from the dropdown " + StoreInnerHTML(byLocator));
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Select a value from drop down using Select by index
	 * 
	 * @param byLocator -> object locator
	 * @param value     -> value to be selected
	 */

	public void SelectValueSelectByIndex(By byLocator, String value) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			ddValue.selectByIndex(Integer.parseInt(value));
			logs.log(Status.INFO, "Selected the option '" + value + "' from the dropdown " + StoreInnerHTML(byLocator));
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify selected option in a drop down by default
	 *
	 * @param byLocator      - > object locator
	 * @param expectedOption -> the expected Option to be verified
	 */
	public void VerifySelectedOption(By byLocator, String expectedOption) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			String selectedOption = ddValue.getFirstSelectedOption().getText();
			String _expectedOption = expectedOption;
			if (selectedOption.equals(_expectedOption)) {
				logs.log(Status.INFO, "Default option display correctly as '**" + selectedOption
						+ "**' in the drop down " + StoreInnerHTML(byLocator));
			} else {
				FailTest("Expected default option is ' " + _expectedOption + " '. But found '" + selectedOption + " '");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store a selected option in a drop down to a variable
	 *
	 * @param byLocator -> object locator
	 */

	public String StoreSelectedOption(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			String selectedOption = ddValue.getFirstSelectedOption().getText();
			logs.log(Status.INFO, "Stored the selected option  '**" + selectedOption + "**'. in dropdown '"
					+ StoreInnerHTML(byLocator) + "'");
			return selectedOption;
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that particular option is displayed in a drop down
	 * 
	 * @param byLocator  -> object locator
	 * @param OptinoName -> option name to be verified
	 * @param i          -> index of the option
	 */

	public void VerifyOption(By byLocator, int i, String OptionName) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));

			List<WebElement> optionList = ddValue.getOptions();
			String ActualOptionName = optionList.get(i).getText();
			String ExpectedOptionName = OptionName;
			if (ActualOptionName.equals(ExpectedOptionName)) {
				logs.log(Status.INFO, "Verification done.Option in dropdown '" + StoreInnerHTML(byLocator)
						+ "' is showing correctly as '**" + ActualOptionName + "**'");
			} else {
				FailTest("Verification fail. Expected Option is '**" + ExpectedOptionName + "**' but found '**"
						+ ActualOptionName + "**'.");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that particular option exists in the drop down
	 * 
	 * @param byLocator  - > object locator
	 * @param OptinoName -> option name to be verified
	 */

	public boolean CheckOptionPresent(By byLocator, String OptionName) {
		boolean OptionPresentStatus = false;
		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			List<WebElement> optionList = ddValue.getOptions();
			for (int i = 0; i < optionList.size(); i++) {
				if (optionList.get(i).getText() != null) {
					if (optionList.get(i).getText().contains(OptionName)) {
						logs.log(Status.INFO, "Option **'" + optionList.get(i).getText()
								+ "**' exists in the dropdown '" + StoreInnerHTML(byLocator) + "'.");
						OptionPresentStatus = true;
						break;
					}
				}
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
		if (OptionPresentStatus == false) {
			FailTest("Dropdown '**" + StoreInnerHTML(byLocator) + "**' doesn't contain '**" + OptionName + "**'option");
		}
		return OptionPresentStatus;
	}

	/**
	 * Get option count in a drop down
	 * 
	 * @param byLocator -> object locator
	 * 
	 */

	public int GetOptionCount(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			List<WebElement> optionList = ddValue.getOptions();
			int optionCount = optionList.size();

			logs.log(Status.INFO, "Dropdown '**" + StoreInnerHTML(byLocator) + "**' has '**" + optionCount
					+ "**' options including default value");
			return optionCount;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify all the option in a drop down
	 *
	 * @param byLocator - > object locator
	 * @param Options   -> Expected list of options to be verified
	 */

	public void CheckAllOptions(By byLocator, String Options) {

		try {
			wait = new WebDriverWait(driver, timeOut);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
		} catch (TimeoutException e) {
		}
		try {
			String[] expectedOptions = Options.split(",");
			if (expectedOptions.length > 1) {
				ArrayList<String> listExpectedoptions = new ArrayList<String>();
				listExpectedoptions.addAll(Arrays.asList(expectedOptions));
				Select ddValue = new Select(getDriver().findElement(byLocator));
				List<WebElement> dropdownList = ddValue.getOptions();
				if (dropdownList.size() == listExpectedoptions.size()) {
					WriteToReport("All the options ( " + dropdownList.size()
							+ " options including default option ) are available in the drop down ' " + byLocator
							+ "' as expected");
					for (int i = 0; i < dropdownList.size(); i++) {
						if (expectedOptions[i].equals(dropdownList.get(i).getText())) {
							WriteToReport(
									"Options ' " + dropdownList.get(i).getText() + " ' is available in the drop down");
						} else {
							logs.log(Status.ERROR, MarkupHelper.createLabel("Expected ' " + expectedOptions[i]
									+ " ' but found ' " + dropdownList.get(i).getText() + " '.", ExtentColor.RED));
							FailTest("Mismatch found in option names");
						}
					}
				} else if (dropdownList.size() > listExpectedoptions.size()) {
					for (int i = 0; i < listExpectedoptions.size(); i++) {
						for (int j = 0; j < dropdownList.size(); j++) {
							if (listExpectedoptions.get(i).equals(dropdownList.get(j).getText())) {
								WriteToReport(
										"Option '" + dropdownList.get(j).getText() + "' is available in the drop down");
								dropdownList.remove(dropdownList.get(j));
							} else {
								WriteFailMessageToReport(
										"Option ' " + expectedOptions[i] + " ' not availabe in the dropdown");
								WriteFailMessageToReport("Additional Option ' " + dropdownList.get(j).getText()
										+ " ' is availabe in the dropdown");
							}
							if (dropdownList.size() > 0) {
								WriteFailMessageToReport("Addtional options ' " + dropdownList.get(j).getText()
										+ " ' is availabe in the dropdown");
							}
						}
					}
					FailTest("Addtional Options are available in the drop down " + byLocator + ".");

				} else {
					for (int i = 0; i < listExpectedoptions.size(); i++) {
						for (int j = 0; j < dropdownList.size(); j++) {
							if (listExpectedoptions.get(i).equals(dropdownList.get(j).getText())) {
								WriteToReport("Optoin '" + listExpectedoptions.get(i) + "' is available in drop down ");
								listExpectedoptions.remove(listExpectedoptions.get(i));
							} else {
								WriteFailMessageToReport(
										"Option ' " + listExpectedoptions.get(i) + " ' not availabe in the dropdown");
							}
						}
					}
					if (listExpectedoptions.size() > 0) {
						FailTest("Missing options in the dropdown " + byLocator + ".");
					}
				}
			} else {
				logs.log(Status.SKIP,
						"At leaset drop down shold have two options. Hence please enter more than or equal to two options in expected option list");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store a text or a message to a variable
	 *
	 * @param byLocator -> object locator
	 */

	public String StoreText(By byLocator) {
		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String elementText = getDriver().findElement(byLocator).getText();
			if (elementText != null && !elementText.isEmpty()) {
				logs.log(Status.INFO, "Stored the text message of element '" + StoreInnerHTML(byLocator)
						+ "' & Stored text is '**" + elementText + "**'");
			} else {
				logs.log(Status.INFO,
						"NO text is availale for the '" + StoreInnerHTML(byLocator) + "' element to be stored.");
			}
			return elementText;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store the property of a element to a variable
	 *
	 * @param byLocator    -> object locator
	 * @param propertyType -> property type (Inner HTML) value of the element need
	 *                     to be stored
	 */

	public String StoreProperty(By byLocator, String propertyType) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}

			String elementProperty = getDriver().findElement(byLocator).getAttribute(propertyType);
			if (elementProperty != null && !elementProperty.isEmpty()) {
				logs.log(Status.INFO, "Stored the Property '" + propertyType + "' of the element"
						+ StoreInnerHTML(byLocator) + " & Stored property is '**" + elementProperty + "**'");
			} else {
				logs.log(Status.INFO, "NO Property value is availale for the property '" + propertyType + "' for the"
						+ StoreInnerHTML(byLocator) + " element to be stored.");
			}
			return elementProperty;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store value property of a element to a variable
	 *
	 * @param byLocator -> object locator
	 */

	public String StoreValue(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String elementValue = getDriver().findElement(byLocator).getAttribute("value");
			if (elementValue != null && !elementValue.isEmpty()) {
				logs.log(Status.INFO, "Stored the value of '" + StoreInnerHTML(byLocator) + "' the element & it is '**"
						+ elementValue + "**'");
			} else {
				logs.log(Status.INFO,
						"No value is availale for the '" + StoreInnerHTML(byLocator) + "'element to be stored.");
			}
			return elementValue;
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the maximum length of the characters that can be entered to a input
	 * field.
	 *
	 * @param byLocator        -> object locator
	 * @param ExpectedMaxCount -> Expected max length of the input field
	 */

	public void VerifyMaxLength(By byLocator, int ExpectedMaxCount) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String randomText = RandomStringUtils.randomAlphabetic(ExpectedMaxCount + 1);
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(randomText);
			String elementValue = getDriver().findElement(byLocator).getAttribute("value");
			if (elementValue != null && !elementValue.isEmpty()) {
				int ActualCharacterCount = elementValue.length();
				int ExpectedCharacterCount = ExpectedMaxCount;
				if (ActualCharacterCount == ExpectedCharacterCount) {
					logs.log(Status.INFO, "Only ' " + ExpectedMaxCount + " ' characters are allowed to enter ' "
							+ StoreInnerHTML(byLocator) + " ' input field");
				} else {
					FailTest("More than ' " + ExpectedMaxCount + " ' characters are allowed to enter ' "
							+ StoreInnerHTML(byLocator) + " ' input field");
				}
			} else {
				String randomIntegers = RandomStringUtils.randomNumeric(ExpectedMaxCount + 1);
				WebElement _element = getDriver().findElement(byLocator);
				_element.clear();
				_element.sendKeys(randomIntegers);
				String _elementValue = getDriver().findElement(byLocator).getAttribute("value");
				if (_elementValue != null && !_elementValue.isEmpty()) {
					int ActualCharacterCount = _elementValue.length();
					int ExpectedCharacterCount = ExpectedMaxCount;
					if (ActualCharacterCount == ExpectedCharacterCount) {
						logs.log(Status.INFO, "Only ' " + ExpectedMaxCount + " ' characters are allowed to enter ' "
								+ StoreInnerHTML(byLocator) + " ' input field");
					} else {
						FailTest("More than ' " + ExpectedMaxCount + " ' characters are allowed to enter ' "
								+ StoreInnerHTML(byLocator) + " ' input field");
					}
				} else {
					logs.log(Status.INFO,
							"No value is availale for the '" + StoreInnerHTML(byLocator) + "'element to be retrieved.");
				}

			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that only integers are allowed to a input field
	 *
	 * @param byLocator -> object locator
	 */

	public void CheckAllowOnlyIntegers(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// Implementing soft assertions
			SoftAssert sAssert = new SoftAssert();
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys("1234567890");
			String IntegerValue = getDriver().findElement(byLocator).getAttribute("value");
			if (IntegerValue != null && !IntegerValue.isEmpty()) {
				int integerCount = IntegerValue.length();
				if (integerCount > 0) {
					WriteToReport("Integers ' " + IntegerValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Integers are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("qwerTYUIopLKJhgfDSAzxcvBNm");
				String characterValue = getDriver().findElement(byLocator).getAttribute("value");
				int CharacterCount = characterValue.length();
				if (CharacterCount > 0) {
					sAssert.fail("Characters ' " + characterValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					WriteToReport("Character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("@!#$~(%^)&*/-_+=:<>?");
				String SpecialelementValue = getDriver().findElement(byLocator).getAttribute("value");
				int SpecialCharacterCount = SpecialelementValue.length();
				if (SpecialCharacterCount > 0) {
					sAssert.fail("Special characters ' " + SpecialelementValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
					sAssert.assertAll();
				} else {
					WriteToReport("Special character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
			} else {
				logs.log(Status.INFO, "No value is availale for the '" + StoreInnerHTML(byLocator)
						+ "'element to get the character length");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that only characters are allowed to a input field
	 *
	 * @param byLocator -> object locator
	 */

	public void CheckAllowOnlyCharacters(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// Implementing soft assertions
			SoftAssert sAssert = new SoftAssert();
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys("qwerTYUIopLKJhgfDSAzxcvBNm");
			String CharacterValue = getDriver().findElement(byLocator).getAttribute("value");
			if (CharacterValue != null && !CharacterValue.isEmpty()) {
				int CharacterCount = CharacterValue.length();
				if (CharacterCount > 0) {
					WriteToReport("Characters ' " + CharacterValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Characters are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("1234567890");
				String IntegerValue = getDriver().findElement(byLocator).getAttribute("value");
				int IntegerCount = IntegerValue.length();
				if (IntegerCount > 0) {
					sAssert.fail("Integers ' " + IntegerValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					WriteToReport("Integers are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("@!#$~(%^)&*/-_+=:<>?");
				String SpecialelementValue = getDriver().findElement(byLocator).getAttribute("value");
				int SpecialCharacterCount = SpecialelementValue.length();
				if (SpecialCharacterCount > 0) {
					sAssert.fail("Special characters ' " + SpecialelementValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					WriteToReport("Special character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				sAssert.assertAll();
			} else {
				logs.log(Status.INFO, "No value is availale for the '" + StoreInnerHTML(byLocator)
						+ "'element to get the character length");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that input field is allowed only alpha numeric, not allowed special
	 * characters
	 *
	 * @param byLocator -> object locator
	 */

	public void CheckNotAllowSpecialCharacters(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// Implementing soft assertions
			SoftAssert sAssert = new SoftAssert();
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys("1234567890");
			String IntegerValue = getDriver().findElement(byLocator).getAttribute("value");
			if (IntegerValue != null && !IntegerValue.isEmpty()) {
				int integerCount = IntegerValue.length();
				if (integerCount > 0) {
					WriteToReport("Integers ' " + IntegerValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Integers are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("qwerTYUIopLKJhgfDSAzxcvBNm");
				String characterValue = getDriver().findElement(byLocator).getAttribute("value");
				int CharacterCount = characterValue.length();
				if (CharacterCount > 0) {
					WriteToReport("Characters ' " + characterValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("@!#$~(%^)&*/-_+=:<>?");
				String SpecialelementValue = getDriver().findElement(byLocator).getAttribute("value");
				int SpecialCharacterCount = SpecialelementValue.length();
				if (SpecialCharacterCount > 0) {
					sAssert.fail("Special characters ' " + SpecialelementValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					WriteToReport("Special character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				sAssert.assertAll();
			} else {
				logs.log(Status.INFO, "No value is availale for the '" + StoreInnerHTML(byLocator)
						+ "'element to get the character length");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that input field is not allowed to enter characters
	 *
	 * @param byLocator -> object locator
	 */

	public void CheckNotAllowCharacters(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// Implementing soft assertions
			SoftAssert sAssert = new SoftAssert();
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys("1234567890");
			String IntegerValue = getDriver().findElement(byLocator).getAttribute("value");
			if (IntegerValue != null && !IntegerValue.isEmpty()) {
				int integerCount = IntegerValue.length();
				if (integerCount > 0) {
					WriteToReport("Integers ' " + IntegerValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Integers are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("@!#$~(%^)&*/-_+=:<>?");
				String SpecialelementValue = getDriver().findElement(byLocator).getAttribute("value");
				int SpecialCharacterCount = SpecialelementValue.length();
				if (SpecialCharacterCount > 0) {
					WriteToReport("Special characters ' " + SpecialelementValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Special character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				sAssert.assertAll();
				element.clear();
				element.sendKeys("qwerTYUIopLKJhgfDSAzxcvBNm");
				String characterValue = getDriver().findElement(byLocator).getAttribute("value");
				int CharacterCount = characterValue.length();
				if (CharacterCount > 0) {
					sAssert.fail("Characters ' " + characterValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					WriteToReport("Character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				sAssert.assertAll();
			} else {
				logs.log(Status.INFO, "No value is availale for the '" + StoreInnerHTML(byLocator)
						+ "'element to get the character length");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that input field is not allowed to enter integers
	 *
	 * @param byLocator -> object locator
	 */

	public void CheckNotAllowIntegres(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// Implementing soft assertions
			SoftAssert sAssert = new SoftAssert();
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys("qwerTYUIopLKJhgfDSAzxcvBNm");
			String CharacterValue = getDriver().findElement(byLocator).getAttribute("value");
			if (CharacterValue != null && !CharacterValue.isEmpty()) {
				int CharacterCount = CharacterValue.length();
				if (CharacterCount > 0) {
					WriteToReport("Characters ' " + CharacterValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Characters are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("@!#$~(%^)&*/-_+=:<>?");
				String SpecialelementValue = getDriver().findElement(byLocator).getAttribute("value");
				int SpecialCharacterCount = SpecialelementValue.length();
				if (SpecialCharacterCount > 0) {
					WriteToReport("Special characters ' " + SpecialelementValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Special character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("0987654321");
				String IntegerValue = getDriver().findElement(byLocator).getAttribute("value");
				int IntegerCount = IntegerValue.length();
				if (IntegerCount > 0) {
					sAssert.fail("Integers ' " + IntegerValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					WriteToReport("Integers are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				sAssert.assertAll();
			} else {
				logs.log(Status.INFO, "No value is availale for the '" + StoreInnerHTML(byLocator)
						+ "'element to get the character length");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify that input field is allowed any character including special characters
	 *
	 * @param byLocator -> object locator
	 */

	public void CheckAllowAnyCharacters(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// Implementing soft assertions
			SoftAssert sAssert = new SoftAssert();
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys("1234567890");
			String IntegerValue = getDriver().findElement(byLocator).getAttribute("value");
			if (IntegerValue != null && !IntegerValue.isEmpty()) {
				int integerCount = IntegerValue.length();
				if (integerCount > 0) {
					WriteToReport("Integers ' " + IntegerValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Integers are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("qwerTYUIopLKJhgfDSAzxcvBNm");
				String characterValue = getDriver().findElement(byLocator).getAttribute("value");
				int CharacterCount = characterValue.length();
				if (CharacterCount > 0) {
					WriteToReport("Characters ' " + characterValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				element.clear();
				element.sendKeys("@!#$~(%^)&*/-_+=:<>?");
				String SpecialelementValue = getDriver().findElement(byLocator).getAttribute("value");
				int SpecialCharacterCount = SpecialelementValue.length();
				if (SpecialCharacterCount > 0) {
					WriteToReport("Special characters ' " + SpecialelementValue + " ' are allowed to enter element ' "
							+ StoreInnerHTML(byLocator) + " '");
				} else {
					sAssert.fail("Special character are not allowed to element '" + StoreInnerHTML(byLocator) + " '");
				}
				sAssert.assertAll();
			} else {
				logs.log(Status.INFO, "No value is availale for the '" + StoreInnerHTML(byLocator)
						+ "'element to get the character length");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Get the count of set of similar elements
	 *
	 * @param byLocator -> object locator
	 */
	public int getCount(By byLocator) {
		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}

			int itemCount = getDriver().findElements(byLocator).size();
			if (itemCount > 0) {
				logs.log(Status.INFO,
						"Item count for the elemets '" + StoreInnerHTML(byLocator) + "' is '**" + itemCount + "**'");
			} else {
				logs.log(Status.INFO, "No Items are available for the '" + StoreInnerHTML(byLocator) + "' element");
			}

			return itemCount;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the count of similar elements
	 *
	 * @param byLocator     -> object locator
	 * @param ExpectedCount -> Expected count to be verified
	 */

	public void VerifyRacordsCounts(By byLocator, int ExpectedCount) {
		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			int ActualitemCount = getDriver().findElements(byLocator).size();
			int ExpectedItemCount = ExpectedCount;
			if (ActualitemCount > 0) {
				if (ActualitemCount == ExpectedItemCount) {
					logs.log(Status.INFO, MarkupHelper.createLabel(
							"Expected & Actual count are tally. & it is showing as '**" + ActualitemCount + "**'.",
							ExtentColor.GREEN));
				} else {
					FailTest("Verification fail. Expected '**" + ExpectedItemCount + "**' but found '**"
							+ ActualitemCount + "**'.");
				}
			} else {
				logs.log(Status.INFO, "No Items are available for the '" + StoreInnerHTML(byLocator) + "' element");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store inner HTML value with the purpose of using in reporting
	 *
	 * @param byLocator -> object locator
	 * 
	 */

	public String StoreInnerHTML(By byLocator) {

		try {

			String elementProperty = null;
			String text = getDriver().findElement(byLocator).getText();
			if (text != null && !text.isEmpty()) {
				elementProperty = text;
			} else {
				String name = getDriver().findElement(byLocator).getAttribute("name");
				if (name != null && !name.isEmpty()) {
					elementProperty = name;
				} else {
					String placeholder = getDriver().findElement(byLocator).getAttribute("placeholder");
					if (placeholder != null && !placeholder.isEmpty()) {
						elementProperty = placeholder;
					} else {
						String id = getDriver().findElement(byLocator).getAttribute("id");
						if (id != null && !id.isEmpty()) {
							elementProperty = id;
						} else {
							String title = getDriver().findElement(byLocator).getAttribute("title");
							if (title != null && !title.isEmpty()) {
								elementProperty = title;
							} else {
								elementProperty = byLocator.toString();
							}
						}
					}
				}
			}
			return elementProperty;
		} catch (NoSuchElementException e) {
			// logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(),
			// ExtentColor.RED));
		}
		return byLocator.toString();
	}

	/**
	 * Mouse hover & click
	 *
	 * @param byMainLink -> the main link to be clicked
	 * @param bySubLink  -> the sub link to be clicked
	 */

	public void MouseHoverAndClick(By byMainLink, By bySubLink) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byMainLink));
			} catch (TimeoutException e) {
			}
			Actions builder = new Actions(driver);
			builder.moveToElement(getDriver().findElement(byMainLink)).perform();
			getDriver().findElement(bySubLink).click();
			logs.log(Status.INFO, "Mouse hover the element '" + StoreInnerHTML(byMainLink) + "' & Click on the '"
					+ StoreInnerHTML(bySubLink) + "' link.");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Navigates back to previous page
	 */
	public void NavigateBack() {

		try {
			getDriver().navigate().back();
			logs.log(Status.INFO, "Navigated back to previous screen");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Navigates forwards to next page
	 */
	public void NavigateForward() {

		try {
			getDriver().navigate().forward();
			;
			logs.log(Status.INFO, "Navigated to next screen");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Navigates to given page or URL
	 * 
	 * @param url -> the URL to be navigated
	 */
	public void NavigateToURL(String url) {

		try {
			getDriver().navigate().to(url);
			logs.log(Status.INFO, "Navigated to the URL '**" + url + "**'successfully");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Refresh the page
	 * 
	 */

	public void Refresh() {

		try {
			getDriver().navigate().refresh();
			logs.log(Status.INFO, "Refreshed the browser successfully");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Explicit Wait with presentOfElemntLocated condition (Wait maximum time till
	 * specific condition meet before throwing exception)
	 *
	 * @param byLocator -> object locator
	 * @param time      - the time to be waited
	 */
	public void WaitForElementPresent(By byLocator) {
		try {
			wait = new WebDriverWait(getDriver(), timeOut);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			logs.log(Status.INFO, "Waited '" + timeOut + "' seconds till elemnt '" + StoreInnerHTML(byLocator)
					+ "' is presented in the page");
		} catch (TimeoutException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Explicit Wait until elementToBbeClickable
	 *
	 * @param byLocator - object locator
	 * @param time      - the time to be waited
	 */
	public void WaitForElementToBeClickable(By byLocator) {
		try {
			wait = new WebDriverWait(getDriver(), timeOut);
			wait.until(ExpectedConditions.elementToBeClickable(byLocator));
			logs.log(Status.INFO, "Waited '" + timeOut + "' seconds till element '" + StoreInnerHTML(byLocator)
					+ "' is to be clickable in the page.");
		} catch (TimeoutException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Implicit Wait - Wait till maximum time exceed before throwing exception
	 * 
	 * @param time -> time to be waited
	 */
	public void Wait(int time) {

		getDriver().manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
		logs.log(Status.INFO, "Waited '" + time + "' seconds till page or element is loaded.");
	}

	/**
	 * Tread Sleep
	 * 
	 * @param time the time
	 */
	public void Sleep(int time) {

		try {
			Thread.sleep(time);
			logs.log(Status.INFO, "Waited '" + time + "' seconds till page or element is loaded.");
		} catch (InterruptedException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Press keyboard keys
	 * 
	 * @param keyLable -> name to the key to be pressed
	 */
	public void PreseKey(String KeyLable) {

		try {
			Robot _Robot = new Robot();
			switch (KeyLable.toUpperCase()) {
			case "Enter":
				_Robot.keyPress(KeyEvent.VK_ENTER);
				_Robot.keyRelease(KeyEvent.VK_ENTER);
				logs.log(Status.INFO, "Press the key '" + KeyLable + "' from the keyboard.");
				break;

			case "Tab":
				_Robot.keyPress(KeyEvent.VK_TAB);
				_Robot.keyRelease(KeyEvent.VK_TAB);
				logs.log(Status.INFO, "Press the key '" + KeyLable + "' from the keyboard.");
				break;

			case "PageUp":
				_Robot.keyPress(KeyEvent.VK_PAGE_UP);
				_Robot.keyRelease(KeyEvent.VK_PAGE_UP);
				logs.log(Status.INFO, "Press the key '" + KeyLable + "' from the keyboard.");
				break;

			case "PageDown":
				_Robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				_Robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
				logs.log(Status.INFO, "Press the key '" + KeyLable + "' from the keyboard.");
				break;

			default:
				logs.log(Status.INFO, "Undefined key is entered");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Verify that element is readonly or not
	 *
	 * @param byLocator the by locator
	 * @param b         whether object is readonly or not
	 */
	/*
	 * public void VerifyElementIsReadOnly(By byLocator, boolean readOnly) {
	 * 
	 * try { try { wait = new WebDriverWait(getDriver(), timeOut);
	 * wait.until(ExpectedConditions.presenceOfElementLocated(byLocator)); } catch
	 * (TimeoutException e) { logs.log(Status.WARNING,
	 * MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER)); }
	 * 
	 * String elementStatus =
	 * getDriver().findElement(byLocator).getAttribute("disabled"); // convert
	 * string value to boolean boolean eleStatus =
	 * Boolean.parseBoolean(elementStatus);
	 * 
	 * // if (elementStatus != null && !elementStatus.isEmpty()) if (readOnly) { if
	 * (eleStatus == readOnly) { logs.log(Status.INFO, "Object " + byLocator +
	 * " is readonly"); } else {
	 * Assert.fail("Expected in read only mode. But it is editable for the Object '"
	 * + byLocator + "'"); } } else { if (eleStatus) {
	 * Assert.fail("Expected editable mode. But it is in readonly for the Object '"
	 * + byLocator + "'"); } else { logs.log(Status.INFO, "Object " + byLocator +
	 * " is editable"); } }
	 * 
	 * } catch (Exception e) { logs.log(Status.ERROR,
	 * MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED)); throw e; } }
	 */
	/**
	 * Verify that set of same type of elements are read only or not
	 *
	 * @param byLocator the by locator
	 * @param b         whether object is read only or not
	 */
	/*
	 * public void VerifyElementsAreReadOnly(By byLocator, boolean readOnly) {
	 * 
	 * try { try { wait = new WebDriverWait(getDriver(), timeOut);
	 * wait.until(ExpectedConditions.presenceOfElementLocated(byLocator)); } catch
	 * (TimeoutException e) { logs.log(Status.WARNING,
	 * MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER)); }
	 * List<WebElement> allelements = driver.findElements(byLocator); for
	 * (WebElement element : allelements) { String elementStatus =
	 * element.getAttribute("disabled"); // convert string value to boolean boolean
	 * eleStatus = Boolean.parseBoolean(elementStatus); if (readOnly) { if
	 * (eleStatus == readOnly) { logs.log(Status.INFO, "Object " + element +
	 * " is readonly"); } else { logs.log(Status.ERROR, MarkupHelper.createLabel(
	 * "Expected in read only mode. But it is editable for the Object '" + element +
	 * "'", ExtentColor.RED)); //
	 * Assert.fail("Expected in read only mode. But it is editable for the Object '"
	 * // + element + "'"); } } else { if (eleStatus) { logs.log(Status.ERROR,
	 * MarkupHelper.createLabel(
	 * "Expected editable mode. But it is in readonly for the Object '" + element +
	 * "'", ExtentColor.RED)); //
	 * Assert.fail("Expected editable mode. But it is in readonly for the Object '"
	 * // + element + "'"); } else { logs.log(Status.INFO, "Object " + element +
	 * " is editable"); } }
	 * 
	 * }
	 * 
	 * } catch (Exception e) { logs.log(Status.ERROR,
	 * MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED)); throw e; } }
	 */

	/**
	 * Fail a test case
	 *
	 * @param message -> message for the failure
	 */
	public void FailTest(String message) {
		Assert.fail(message);
	}

	/**
	 * Scroll Down
	 * 
	 */
	public void ScrollDown() {
		try {
			JavascriptExecutor jsx = (JavascriptExecutor) getDriver();
			jsx.executeScript("window.scrollBy(0,450)", "");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Scroll Up
	 * 
	 */
	public void ScrollUp() {
		try {
			JavascriptExecutor jsx = (JavascriptExecutor) getDriver();
			jsx.executeScript("", "window.scrollBy(0,450)");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Upload a file using Robot Class
	 * 
	 * @param imageName -> name of the image to be uploaded & Image should be
	 *                  located in resources folder
	 * 
	 */

	public void FileUpload(String fileName) {

		String filepath = System.getProperty("user.dir") + "\\resources\\" + fileName;
		StringSelection sel = new StringSelection(filepath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sel, null);
		// Create object of Robot class
		try {
			Robot robot = new Robot();
			robot.delay(1000);
			// Press CTRL+V
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			// Release CTRL+V
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			logs.log(Status.INFO, "Uploaded the file '**" + fileName + "**'.");
		} catch (AWTException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Get the font color of an element
	 *
	 * @param byLocator -> object locator
	 * 
	 */

	public String GetFontColur(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String elementColour = getDriver().findElement(byLocator).getCssValue("color");
			String hexColur = Color.fromString(elementColour).asHex();
			if (hexColur != null && !hexColur.isEmpty()) {
				logs.log(Status.INFO,
						"Font colour of element '" + StoreInnerHTML(byLocator) + "' is '**" + hexColur + "**'");
			} else {
				logs.log(Status.INFO, "No Font Color is availale for the '" + StoreInnerHTML(byLocator) + "'element");
			}
			return hexColur;
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Get the background color of an element
	 *
	 * @param byLocator -> object locator
	 * 
	 */

	public String GetBackgroundColur(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			String elementbgColour = getDriver().findElement(byLocator).getCssValue("background-color");
			String hexbgColur = Color.fromString(elementbgColour).asHex();
			if (hexbgColur != null && !hexbgColur.isEmpty()) {
				logs.log(Status.INFO, "Background colour of element '**" + StoreInnerHTML(byLocator) + "**' is '**"
						+ hexbgColur + "**'");
			} else {
				logs.log(Status.INFO,
						"No Background Color is availale for the '" + StoreInnerHTML(byLocator) + " 'element");
			}
			return hexbgColur;
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Get the count of matching result for a particular text from a item list
	 *
	 * @param byLocator - > object locator
	 * @param FindText  - > Text name to be searched or found
	 */

	public int FindMatchCount(By byLocator, String FindText) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			List<WebElement> elementNames = getDriver().findElements(byLocator);
			int itemCount = elementNames.size();
			if (itemCount > 0) {
				int matchingCount = 0;
				for (int i = 0; i < itemCount; i++) {
					String prudducnName = elementNames.get(i).getText();
					if (prudducnName.equals(FindText)) {
						matchingCount++;
					}
				}
				if (matchingCount == 0) {
					logs.log(Status.INFO, "No matching item found for the '**" + FindText + "**' text in the '**"
							+ StoreInnerHTML(byLocator) + "**' element. Total item count is '**" + itemCount + "'.");
				} else {
					logs.log(Status.INFO,
							"'**" + matchingCount + "**' out of '**" + itemCount
									+ "**' matching items found for the '**" + FindText + "**' text in the '**"
									+ StoreInnerHTML(byLocator) + "**' element.");
				}
				return matchingCount;
			} else {
				logs.log(Status.INFO,
						"No matching records found for the element '**" + StoreInnerHTML(byLocator) + "**'");
				return 0;
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the matching records for a particular search
	 *
	 * @param byLocator the by locator
	 * @param FindText  - > Text name to be searched or found
	 */

	public void VerifyMatchText(By byLocator, String FindText) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			List<WebElement> elementNames = getDriver().findElements(byLocator);
			int itemCount = elementNames.size();
			if (itemCount > 0) {
				int unmatchCount = 0;
				for (int i = 0; i < itemCount; i++) {
					String itemName = elementNames.get(i).getText();
					if (!itemName.equals(FindText)) {
						unmatchCount++;
						FailTest("Incorrect record found. element '**" + itemName + "**' not matched with '**"
								+ FindText + "**' search item ");
					}
				}
				if (unmatchCount > 0) {
					FailTest("Incorrect matching recods");
				} else {
					logs.log(Status.INFO, "No mismatch found after searching for '**" + FindText + "**'");
				}
			} else {
				logs.log(Status.INFO,
						"No matching records found for the element '**" + StoreInnerHTML(byLocator) + "**'");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Select All check boxes for a particular item
	 *
	 * @param byLocator -> object locator
	 */

	public void SelectAllCheckBoxes(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			List<WebElement> allcheckboxes = driver.findElements(byLocator);
			for (WebElement element : allcheckboxes) {
				if (!element.isSelected()) {
					element.click();
				}
			}
			logs.log(Status.INFO,
					"Selected all the checkboxes matched to element '**" + StoreInnerHTML(byLocator) + "**'");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Select multiple check boxes for a particular item
	 *
	 * @param byLocator -> object locator
	 */

	public void SelectCheckBox(By byLocator, String checkboxes) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			// int temp=0;
			String[] checkBoxesToBeClicked = checkboxes.split(",");
			List<WebElement> allcheckboxes = driver.findElements(byLocator);

			System.out.println(allcheckboxes.size());
			for (int i = 0; i < checkBoxesToBeClicked.length; i++) {
				for (int j = 0; j < allcheckboxes.size(); j++) {
					if (checkBoxesToBeClicked[i].contains(allcheckboxes.get(j).getText())) {
						WriteToReport("Selected check box ' " + allcheckboxes.get(j).getText() + " '");
						System.out.println(checkBoxesToBeClicked[i]);
						System.out.println(allcheckboxes.get(j).getText());
						allcheckboxes.remove(allcheckboxes.get(j));
						WriteToReport("list size is " + allcheckboxes.size());
					}

					/*
					 * if(!checkBoxesToBeClicked[i].contains(allcheckboxes.get(j).getText())) {
					 * WriteFailMessageToReport("Check box"); }
					 */
				}
				/*
				 * for (WebElement element : allcheckboxes) {
				 * if(Arrays.asList(checkBoxesToBeClicked).contains(element.getText())) {
				 * 
				 * if (!element.isSelected()) { // allcheckboxes.get(j).click();
				 * WriteToReport("Selected check box ' " + element.getText() + " '"); break; //
				 * } }
				 * 
				 * 
				 * //if(element.getText().equals(Arrays.toString(checkBoxesToBeClicked)))
				 * 
				 * 
				 * } else { WriteFailMessageToReport("Check box ' " + element.getText() +
				 * " ' not found, but found '" + checkBoxesToBeClicked[i]); }
				 * 
				 * } }
				 */
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * compare data set of tow string arrays
	 *
	 * @param Expected[] -> Array of the Expected data set
	 * @param Actual[] -> Array of the Actual data set
	 */

	public void CompareTowArray(String[] Expected, String[] Actual) {

		try {
			for (int i = 0; i < Expected.length; i++) {
				if (!Expected[i].equals(Actual[i])) {
					FailTest("Mismatch found. Expected '**" + Expected[i] + "**' But found '**" + Actual[i] + "**'");
				} else {
					logs.log(Status.INFO, "No mismatch found comparing tow arrays");
				}
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Click on a searched or a selected element
	 *
	 * @param byLocator    -> object locator
	 * @param SelectedItem -> selected or searched item name
	 */

	public void ClickedOnSelectedItem(By byLocator, String SelectedItem) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
			}
			List<WebElement> elementNames = getDriver().findElements(byLocator);
			for (WebElement element : elementNames) {
				if (element.isDisplayed() && element.getText().equals(SelectedItem)) {
					element.click();
					logs.log(Status.INFO, "Clicked on the element '**" + byLocator + "**' matching with **'"
							+ SelectedItem + "**' text");
					break;
				}
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify set of similar elements exist in the web page
	 *
	 * @param byLocator -> The object locator
	 * @param elements  -> Expected list of elements to be verified
	 */

	public void CheckAllElements(By byLocator, String elements) {

		try {
			wait = new WebDriverWait(driver, timeOut);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
		} catch (TimeoutException e) {
		}
		try {
			String[] expectedElements = elements.split(",");
			if (expectedElements.length > 0) {
				ArrayList<String> listExpectedElements = new ArrayList<String>();
				listExpectedElements.addAll(Arrays.asList(expectedElements));

				List<WebElement> elementNames = getDriver().findElements(byLocator);
				if (elementNames.size() == listExpectedElements.size()) {
					WriteToReport("All the elements ( " + elementNames.size() + "  ) are available in object' "
							+ byLocator + "' as expected");
					for (int i = 0; i < elementNames.size(); i++) {
						if (expectedElements[i].equals(elementNames.get(i).getText())) {
							WriteToReport("Element ' " + elementNames.get(i).getText() + " ' is available.");
						} else {
							logs.log(Status.ERROR, MarkupHelper.createLabel("Expected ' " + expectedElements[i]
									+ " ' but found ' " + elementNames.get(i).getText() + " '.", ExtentColor.RED));
							FailTest("Mismatch found in elements names");
						}
					}
				} else if (elementNames.size() > listExpectedElements.size()) {
					for (int i = 0; i < listExpectedElements.size(); i++) {
						for (int j = 0; j < elementNames.size(); j++) {
							if (listExpectedElements.get(i).equals(elementNames.get(j).getText())) {
								WriteToReport("Element '" + elementNames.get(j).getText() + "' is available in the.");
								elementNames.remove(elementNames.get(j));
							} else {
								WriteFailMessageToReport("Element ' " + expectedElements[i] + " ' not availabe");
								WriteFailMessageToReport(
										"Additional Elemnt ' " + elementNames.get(j).getText() + " ' is availabe.");
							}
							if (elementNames.size() > 0) {
								WriteFailMessageToReport(
										"Addtional element ' " + elementNames.get(j).getText() + " ' is availabe");
							}
						}
					}
					FailTest("Addtional elements are available " + byLocator + ".");

				} else {
					for (int i = 0; i < listExpectedElements.size(); i++) {
						for (int j = 0; j < elementNames.size(); j++) {
							if (listExpectedElements.get(i).equals(elementNames.get(j).getText())) {
								WriteToReport("Element '" + listExpectedElements.get(i) + "' is available.");
								listExpectedElements.remove(listExpectedElements.get(i));
							} else {
								WriteFailMessageToReport(
										"Element ' " + listExpectedElements.get(i) + " ' not availabe.");
							}
						}
					}
					if (listExpectedElements.size() > 0) {
						FailTest("Missing Elements in the." + byLocator + ".");
					}
				}
			} else {
				logs.log(Status.SKIP,
						"At leaset you need to enter one name. Hence please enter more one element in expected element list");
			}
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Write something on the report.
	 *
	 * @param message -> the message to be written
	 */

	public void WriteToReport(String message) {

		try {
			logs.log(Status.INFO, message);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Write failure message to report in red color
	 *
	 * @param message - the message to be written
	 */

	public void WritePassMessgeToReport(String message) {

		try {
			logs.log(Status.INFO, MarkupHelper.createLabel(message, ExtentColor.GREEN));
		} catch (Exception e) {
		}
	}

	/**
	 * Write failure message to report in red color
	 *
	 * @param message - the message to be written
	 */

	public void WriteFailMessageToReport(String message) {

		try {
			logs.log(Status.ERROR, MarkupHelper.createLabel(message, ExtentColor.RED));
		} catch (Exception e) {
		}
	}

}
