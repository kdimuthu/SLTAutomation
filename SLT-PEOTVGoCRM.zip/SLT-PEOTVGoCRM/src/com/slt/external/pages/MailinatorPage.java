package com.slt.external.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class MailinatorPage extends TestBase_Commands {
	private static By tf_Search = By.xpath("//a[contains(text(),'Email')]/preceding::input[2]");
	private static By btn_Go=By.xpath("//a[contains(text(),'Email')]/preceding::button[2]");
	

	public MailinatorPage(WebDriver driver) {
		this.driver = driver;
	}

	// Navigate to mailinator
	public void bf_NavigatesToMail(String prm_EmailName) {
		
		Open("https://www.mailinator.com/");
		Type(tf_Search, prm_EmailName);
		
		//String EnterdValue=prm_EmailName;
	//	VerifyText(tf_Search, "test");
	//	VerifyText(btn_Go, "dfd");
		Click(btn_Go);
	}
	
	public String bf_StoreEnteredValue(String prm_EmailName) {
		
		return prm_EmailName+"@mailinator.com";
	}
}
