package com.slt.selfcareportal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class AccountCreationPage extends TestBase_Commands {
	private static By lbl_HeaderYourACcount = By.xpath("//div[contains(text(),'Account')]");
	private static By msg_PleaseUse = By.xpath("//h6[contains(text(),'Please')]");
	private static By lbl_VerificationCode = By.xpath("//h6[contains(text(),'Please')]/following::div[1]");
	private static By btn_Close = By.xpath("//a[text()='Close']");
	private static By lbl_YourValidationCodeIs = By.xpath("//div[contains(text(),'Validation')]");
	private static By val_ValidationCode = By.xpath("//div[contains(text(),'Validation')]/span");
	private static By lnk_AccessSelfcare = By.xpath("//div[contains(text(),'Validation')]/a");

	public AccountCreationPage(WebDriver driver) {
		this.driver = driver;
	}

	// Verify the header of Your account created UI
	public void bf_VerifyHeaderOfYourAccountCreated() {
		VerifyHeader(lbl_HeaderYourACcount, "Your Account is successfully created");
	}

	// Verify the Account Creation UI after creating an account
	public void bf_VerifyAccountCreationUI() {
		//Verify the header message exists
		CheckElementPresent(lbl_HeaderYourACcount,true);
		//Verify the message please use exists
		CheckElementPresent(msg_PleaseUse,true);
		//Verify the verification code exists
		CheckElementPresent(lbl_VerificationCode,true);
		//Verify the close button exists
		CheckElementPresent(btn_Close,true);
	}

	// Store the generated verification code
	public String bf_StoreVerificationCode() {
		String VerificationCode = StoreText(lbl_VerificationCode);
		WriteToReport("Genarated verifaction code is : " + VerificationCode);
		return VerificationCode;
	}

	// Click Close from the Account Creation screen
	public void bf_CloseMessageYourAccountIsSuccessfullyCreated() {
		Click(btn_Close);
	}

	// Verify the UI after closing Account Creation screen
	public void bf_VerifyUIAfterClossingAccountCreationWindow(String prm_StoredVerificationCode) {
		
		String megYourValidationCodeIs=StoreText(lbl_YourValidationCodeIs);	
		// Verify the message Your Validation Code Is
		VerifyText(lbl_YourValidationCodeIs, megYourValidationCodeIs);
		// Verify the validation code
		String ValidationCode = StoreText(val_ValidationCode);
		if (prm_StoredVerificationCode.equals(ValidationCode)) {
			WriteToReport("Verification Code is showing correctly in both placess as " + ValidationCode);
		} else {
			WriteToReport("Verification Code in first screen is " + bf_StoreVerificationCode() + "Where as it is"
					+ ValidationCode + "in the second screen");
		}
		

	}
	
	//Navigates to access portal
	public void bf_NavigatesToAccessPortal() {
		Click(lnk_AccessSelfcare);
	}

}
