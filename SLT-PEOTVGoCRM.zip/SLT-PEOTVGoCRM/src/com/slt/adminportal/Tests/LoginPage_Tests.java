package com.slt.adminportal.Tests;

import org.testng.annotations.Test;

import com.slt.adminportal.pages.LandingPage;
import com.slt.adminportal.pages.LoginPage;
import Utility.SeleniumTestBase;

public class LoginPage_Tests extends SeleniumTestBase {
	LoginPage _LoginPage;
	LandingPage _LandingPage;

	// Verify that user is able to Login with valid credentials
	@Test(priority = 1, enabled = false)
	public void tc_Login() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_LoginToAdminPortal("admin", "1234");
		_LandingPage = new LandingPage(driver);
		_LandingPage.bf_VeriyHeaderOfLandinPage();
	}

	// Verify the login page UI
	@Test(priority = 2, enabled = false)
	public void tc_VerifyLoginUI() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_VeriyfLoginUI();

	}

	// Verify the invalid login tests
	@Test(priority = 3, enabled = true)
	public void tc_VerifyInvalidLogin() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_VerifyMessagesWhenLoingIsInvalid("admin", "1234", "hjfhdj", "dfkdj8", "Email is Required",
				"Password is Required", "Invalid Username or Password");

	}

}
