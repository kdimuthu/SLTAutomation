package com.slt.adminportal.Tests;

import org.testng.annotations.Test;

import com.slt.adminportal.pages.AddNewProductPage;
import com.slt.adminportal.pages.LandingPage;
import com.slt.adminportal.pages.LoginPage;
import com.slt.adminportal.pages.ProductListningPage;

import Utility.SeleniumTestBase;

public class Channels_Tests extends SeleniumTestBase {
	LoginPage _LoginPage;
	LandingPage _LandingPage;
	ProductListningPage _ProductListningPage;
	AddNewProductPage _AddNewProductPage;

	// Verify the channel listing page UI
	@Test(priority = 1, enabled = false)
	public void tc_VerifyChannelListingPageUI() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_LoginToAdminPortal("admin", "1234");
		_LandingPage = new LandingPage(driver);
		_LandingPage.bf_ClickOnAProuduc("CHANNELS");
		_ProductListningPage = new ProductListningPage(driver);
		_ProductListningPage.bf_VeriyHeaderOfProductListningPage("Channels");
		_ProductListningPage.bf_VeriyChannlListingUI("Channels");
		_LandingPage.bf_LogOutInAdminPortal();
	}

	// Verify the Add new channel page UI
	@Test(priority = 1, enabled = true)
	public void tc_VerifyAddNewChannelUI() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_LoginToAdminPortal("admin", "1234");
		_LandingPage = new LandingPage(driver);
		_LandingPage.bf_ClickOnAProuduc("CHANNELS");
		_ProductListningPage = new ProductListningPage(driver);
		_ProductListningPage.bf_ClickAddNewButton();
		_AddNewProductPage = new AddNewProductPage(driver);
		_AddNewProductPage.bf_VeriyHeaderOfAddNewProductPage("Add new channel");
		_AddNewProductPage.bf_VeriyAddNewChannelUI();
		_LandingPage.bf_LogOutInAdminPortal();
	}
}
