package com.slt.adminportal.Tests;

import org.testng.annotations.Test;

import com.slt.adminportal.pages.LandingPage;
import com.slt.adminportal.pages.LoginPage;
import Utility.SeleniumTestBase;

public class LandingPage_Tests extends SeleniumTestBase {
	LoginPage _LoginPage;
	LandingPage _LandingPage;

	// Verify the landing page UI & Log out from the landing page
	@Test(priority = 1, enabled = true)
	public void tc_VerifyLandingPageUI() {
		_LoginPage = new LoginPage(driver);
		String adminUsername="admin";
		_LoginPage.bf_LoginToAdminPortal(adminUsername, "1234");		
		_LandingPage = new LandingPage(driver);
		_LandingPage.bf_VerifyLandingPageUI(adminUsername);
		_LandingPage.bf_LogOutInAdminPortal();
	}

}
