package com.slt.adminportal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class LandingPage extends TestBase_Commands {

	private static By btn_LogOut = By.xpath("//button[text()='LOG OUT']");
	private static By lbl_UserName = By.xpath("//button[text()='LOG OUT']/preceding::h4");
	private static By dd_Product = By.xpath("");
	private static By btn_Channel = By.xpath("//h2[text()='CHANNELS']");
	private static By btn_VOD = By.xpath("//h2[text()='VOD']");
	private static By btn_MOD = By.xpath("//h2[text()='MOD']");
	private static By btn_Screens = By.xpath("//h2[text()='SCREENS']");
	private static By btn_ChannelBundle = By.xpath("//h2[text()='CHANNEL BUNDLE']");
	private static By btn_VODBundle = By.xpath("//h2[text()='VOD BUNDLE']");
	private static By btn_BasePackages = By.xpath("//h2[text()='BASE PACKAGES']");
	private static By btn_PrimaryPackages = By.xpath("//h2[text()='PRIMARY PACKAGES']");
	private static By btn_PurchaseOption = By.xpath("//h2[text()='PURCHASE OPTION']");
	private static By btn_PricingOption = By.xpath("//h2[text()='PRICING OPTION']");
	private static By lnk_ChannelinMenu = By.xpath("");
	private static By lnk_VODinMenu = By.xpath("");
	private static By lnk_MODinMenu = By.xpath("");
	private static By lnk_ScreensinMenu = By.xpath("");
	private static By dd_BundleinMenu = By.xpath("");
	private static By lnk_VODBundleinMenu = By.xpath("");
	private static By lnk_BasePackagesinMenu = By.xpath("");
	private static By lnk_PrimaryPackagesinMenu = By.xpath("");
	private static By lnk_PurchaseOptioninMenu = By.xpath("");
	private static By lnk_PricingOptioninMenu = By.xpath("");
	private static By btn_Allbuttons = By.xpath("//div[@class='tableCell']//h2");

	public LandingPage(WebDriver driver) {
		this.driver = driver;
	}

	// Verify the header in landing page
	public void bf_VeriyHeaderOfLandinPage() {

		WriteToReport("=======Start of bf_VeriyHeaderOfLandinPage========");
		// Verify that logout element exist in the page
		VerifyHeader(btn_LogOut, "LOG OUT");
		// Verify that Channels button exits
		CheckElementPresent(btn_Channel, true);

		WriteToReport("=======End of bf_VeriyHeaderOfLandinPage=========");
	}

	// Click on product button
	public void bf_ClickOnAProuduc(String pruductName) {

		WriteToReport("=======Start of bf_ClickOnAProuduct========");
		ClickedOnSelectedItem(btn_Allbuttons, pruductName);

		WriteToReport("=======End of bf_ClickOnAProuduct=========");
	}

	// Verify the landing page UI
	public void bf_VerifyLandingPageUI(String prm_Storeusername) {

		WriteToReport("=======Start of bf_VerifyLandingPageUI=========");
		// Verify that logout element exist in the page
		CheckElementPresent(btn_LogOut, true);
		// Verify the user name is correct
		String LogedUsername = StoreText(lbl_UserName).toLowerCase();
		if (LogedUsername.contentEquals(prm_Storeusername)) {
			WriteToReport("User name is showing correctly as " + LogedUsername);
		} else {
			FailTest("Inccorect user name is showing. Expected '" + prm_Storeusername + "' but found "
					+ LogedUsername);
		}
		// Verify that button channel exist
		CheckElementPresent(btn_Channel, true);
		// Verify that button Vod exist
		CheckElementPresent(btn_VOD, true);
		// Verify that button Mod exist
		CheckElementPresent(btn_MOD, true);
		// Verify that button Screens exist
		CheckElementPresent(btn_Screens, true);
		// Verify that button channel bundle exist
		CheckElementPresent(btn_ChannelBundle, true);
		// Verify that button VOD bundle exist
		CheckElementPresent(btn_VODBundle, true);
		// Verify that button BasePackages exist
		CheckElementPresent(btn_BasePackages, true);
		// Verify that button PrimaryPackages exist
		CheckElementPresent(btn_PrimaryPackages, true);
		// Verify that button Purchase Option exist
		CheckElementPresent(btn_PurchaseOption, true);
		// Verify that button Pricing Option exist
		CheckElementPresent(btn_PricingOption, true);
		// Verify that addition buttons not showing in the page
		int buttonCount = getCount(btn_Allbuttons);
		if (buttonCount == 10) {
			WriteToReport("Showing 10 buttons to create products");
		} else if (buttonCount > 10) {
			FailTest("Addtions buttons to create product is showing");
		}

		/*
		 * // Verify the link Channels in the menu
		 * CheckElementPresent(lnk_ChannelinMenu,true); // Verify the link VOD in the
		 * menu CheckElementPresent(lnk_VODinMenu,true); // Verify the link MOD in the
		 * menu CheckElementPresent(lnk_MODinMenu,true); // Verify the link screens in
		 * the menu CheckElementPresent(lnk_ScreensinMenu,true); // Verify the dropdown
		 * bundle in the menu CheckElementPresent(dd_BundleinMenu,true);
		 * 
		 */

		WriteToReport("=======End of bf_VerifyLandingPageUI=========");
	}

	// Log out
	public void bf_LogOutInAdminPortal() {

		WriteToReport("=======Start of bf_LogOutInAdminPortal==========");
		// Click LogOut
		Click(btn_LogOut);

		WriteToReport("========End of bf_VeriyHeaderOfLandinPage========");
	}

}
