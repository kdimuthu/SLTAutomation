package com.slt.adminportal.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class AddNewProductPage extends TestBase_Commands {

	private static By lbl_ProductName = By.xpath("//button[text()='LOG OUT']/following::h1");
	private static By tf_ChannelName = By.id("channelName");
	private static By tf_ERN = By.id("erNumber");
	private static By icn_ERN = By.xpath("//input[@id='erNumber']/following::button[1]");
	private static By tf_DRN = By.id("drNumber");
	private static By icn_DRN = By.xpath("//input[@id='erNumber']/following::button[2]");
	private static By tf_ChannelNumber = By.id("channelNumber");
	private static By tf_ChannelDescription = By.id("channelDescription");
	private static By lbl_CountMessage = By.id("count_message");
	private static By dd_SelectKey = By.xpath("//button[contains(text(),'Select')]");
	private static By opt_AllSelectKey = By.xpath("//button[contains(text(),'Select')]/following::div[1]/a");
	private static By tf_SelectKey = By.id("metadataValue");
	private static By btn_AddSelectKey = By.xpath("//input[@id='metadataValue']/following::button[1]");
	private static By btn_Status = By.xpath("//label[text()='Status']/following::button[1]");
	private static By opt_AllStatus = By.xpath("//label[text()='Status']/following::a[contains(@id,'PRODUCT_STATUS')]");
	// private static By opt_StatusInactive =
	// By.xpath("//label[text()='Status']/following::a[2]");
	private static By btn_Image = By.id("logo");
	private static By btn_AddNewCategory = By.xpath("//label[text()='Select Category']/following::button[1]");
	private static By chk_AllSelectCategoryCheckboxes = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined']");
	private static By chk_ForeignVariety = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][1]");
	private static By chk_News = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][2]");
	private static By chk_Infotainment = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][3]");
	private static By chk_LocalVariety = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][4]");
	private static By chk_Kids = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][5]");
	private static By chk_Movie = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][6]");
	private static By chk_Learnig = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][7]");
	private static By chk_Religios = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][8]");
	private static By chk_Tamil = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][9]");
	private static By chk_Travel = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][10]");
	private static By chk_Music = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][11]");
	private static By chk_Local = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][12]");
	private static By chk_Sports = By
			.xpath("//label[text()='Select Category']/following::input[@id='checkboxundefined'][13]");
	private static By tf_PGRating = By.id("pgRating");
	private static By chk_AllFeaturesCheckboxes = By
			.xpath("//label[text()='Features']/following::input[@type='checkbox']");
	private static By chk_TSTV = By.id("TSTV");
	private static By chk_PIP = By.id("PIP");
	private static By chk_CPVR = By.id("CPVR");
	private static By btn_AddNewAllowedRegions = By.xpath("//label[text()='Allowed Regions']/following::button[1]");
	private static By dd_AllowedRegions = By.xpath("//div[contains(text(),'Select')]");
	private static By tf_PurchaseStartDate = By
			.xpath("//label[text()='Purchase' and text()=' start date']/following::input[1]");
	private static By tf_PurchaseEndDate = By
			.xpath("//label[text()='Purchase' and text()=' start date']/following::input[2]");
	private static By tf_UtilizationStartDate = By
			.xpath("//label[text()='Purchase' and text()=' start date']/following::input[3]");
	private static By tf_UtilizationEndtDate = By
			.xpath("//label[text()='Purchase' and text()=' start date']/following::input[4]");
	private static By dd_Prerequisites = By.xpath("//button[text()='Prerequisites']");
	private static By opt_AllPrerequisites = By.xpath("//a[contains(@name,'Prerequisite')]");
	private static By btn_AddNewPrerequisites = By.xpath("//button[text()='Prerequisites']/following::button[1]");
	private static By tbl_ExistingPrerequisites = By.xpath("//button[text()='Prerequisites']/following::button[2]");
	private static By dd_PurchaseOption = By.xpath("//button[text()='Purchase Options']");
	private static By opt_AllPurOptions = By.xpath("//button[text()='Purchase Options']/following::a");
	private static By btn_AddNewPurchaseOptions = By.xpath("//button[text()='Purchase Options']/following::button[1]");
	private static By tbl_ExistingPurchaseOptions = By
			.xpath("//button[text()='Purchase Options']/following::button[2]");
	private static By btn_AddProduct = By.xpath("//button[@type='submit']");

	public AddNewProductPage(WebDriver driver) {
		this.driver = driver;

	}

	// Verify the header of add new product page
	public void bf_VeriyHeaderOfAddNewProductPage(String prm_ProductName) {

		WriteToReport("=======Start of bf_VeriyHeaderOfAddNewProductPage========");
		// Verify that header of add product page
		VerifyHeader(lbl_ProductName, prm_ProductName);

		WriteToReport("=======End of bf_VeriyHeaderOfAddNewProductPage=========");
	}

	// Verify the add new channel UI
	public void bf_VeriyAddNewChannelUI() {

		WriteToReport("=======Start of bf_VeriyAddNewChannelUI========");
		// Verify that channel name text field exist & enabled
		CheckElementEnabled(tf_ChannelName, true);
		// Verify that External Reference Number text field exist & enabled
		CheckElementEnabled(tf_ERN, true);
		// Verify that help icon for the ERN field exist in web page
		CheckElementPresent(icn_ERN, true);
		// Verify that Downstream Reference Number text field exist & enabled
		CheckElementEnabled(tf_DRN, true);
		// Verify that help icon for the DRN field exist in web page
		CheckElementPresent(icn_DRN, true);
		// Verify that channel number text field exist & enabled
		CheckElementEnabled(tf_ChannelNumber, true);
		// Verify that channel description text field exist & enabled
		CheckElementEnabled(tf_ChannelDescription, true);
		// Verify the count message for the channel description field
		VerifyText(lbl_CountMessage, "1000 characters remain");
		// Verify that Select Key drop down exist in web page
		CheckElementPresent(dd_SelectKey, true);
		// Verify that additional details text field exist & enabled
		CheckElementEnabled(tf_SelectKey, true);
		// Verify that add new select category button exist & enabled
		CheckElementEnabled(btn_AddSelectKey, false);
		// Verify the values in Select Key drop down
		bf_ClickSelectKeyDropdown();
		CheckAllElements(opt_AllSelectKey, "Cast,Director,Country,Duration,Year,HD,Subtitles,Audio");
		Refresh();
		// Verify the status drop down exists in the page
		CheckElementPresent(btn_Status, true);
		// Verify the values in status drop down
		bf_ClickStausDropdown();
		CheckAllElements(opt_AllStatus, "Active,Deactive");
		Refresh();
		// Verify the image upload section exists in the page
		CheckElementPresent(btn_Image, true);
		// Verify that Add new Select category button is exits & enabled in the page
		CheckElementEnabled(btn_AddNewCategory, true);
		// Verify that Foreign Variety exists, enables & selected
		CheckElementEnabled(chk_ForeignVariety, true);
		CheckElementSelected(chk_ForeignVariety, false);
		// Verify that News / Business exists, enables & selected
		CheckElementEnabled(chk_News, true);
		CheckElementSelected(chk_News, false);
		// Verify that Infotainment exists, enables & selected
		CheckElementEnabled(chk_Infotainment, true);
		CheckElementSelected(chk_Infotainment, false);
		// Verify that Local Variety exists, enables & selected
		CheckElementEnabled(chk_LocalVariety, true);
		CheckElementSelected(chk_LocalVariety, false);
		// Verify that Kids exists, enables & selected
		CheckElementEnabled(chk_Kids, true);
		CheckElementSelected(chk_Kids, false);
		// Verify that Movie exists, enables & selected
		CheckElementEnabled(chk_Movie, true);
		CheckElementSelected(chk_Movie, false);
		// Verify that Learning & Educational exists, enables & selected
		CheckElementEnabled(chk_Learnig, true);
		CheckElementSelected(chk_Learnig, false);
		// Verify that Religious exists, enables & selected
		CheckElementEnabled(chk_Religios, true);
		CheckElementSelected(chk_Religios, false);
		// Verify that Tamil exists, enables & selected
		CheckElementEnabled(chk_Tamil, true);
		CheckElementSelected(chk_Tamil, false);
		// Verify that Travel & Living exists, enables & selected
		CheckElementEnabled(chk_Travel, true);
		CheckElementSelected(chk_Travel, false);
		// Verify that Music exists, enables & selected
		CheckElementEnabled(chk_Music, true);
		CheckElementSelected(chk_Music, false);
		// Verify that Local Music exists, enables & selected
		CheckElementEnabled(chk_Local, true);
		CheckElementSelected(chk_Local, false);
		// Verify that Sports exists, enables & selected
		CheckElementEnabled(chk_Sports, true);
		CheckElementSelected(chk_Sports, false);
		// Verify that PG Rating text field is exists & enabled
		CheckElementEnabled(tf_PGRating, true);
		// Verify that Feature TSTV exists, enables & selected
		CheckElementEnabled(chk_TSTV, true);
		CheckElementSelected(chk_TSTV, false);
		// Verify that Feature PIP exists, enables & selected
		CheckElementEnabled(chk_PIP, true);
		CheckElementSelected(chk_PIP, false);
		// Verify that Feature CPVR exists, enables & selected
		CheckElementEnabled(chk_CPVR, true);
		CheckElementSelected(chk_CPVR, false);
		//Verify Allowed Regions drop down exist
		CheckElementPresent(dd_AllowedRegions, true);
		//Verify that Add new Allowed Region is exists & enabled
		CheckElementEnabled(btn_AddNewAllowedRegions, true);
		// Verify that Purchase start date field is exists & enabled
		CheckElementEnabled(tf_PurchaseStartDate, true);
		// Verify that Purchase end date field is exists & enabled
		CheckElementEnabled(tf_PurchaseEndDate, true);
		// Verify that Purchase start date field is exists & enabled
		CheckElementEnabled(tf_UtilizationStartDate, true);
		// Verify that Purchase end date field is exists & enabled
		CheckElementEnabled(tf_UtilizationEndtDate, true);
		// verify the Purchase start date field default value
		VerifyElementShowCurrentDate(tf_PurchaseStartDate);
		// Verify the default date of Purchase end date
		VerifyDate(tf_PurchaseEndDate, "2050-12-31");
		// verify the Utilization start date field default value
		VerifyElementShowCurrentDate(tf_UtilizationStartDate);
		// Verify the default date of Utilization end date
		VerifyDate(tf_UtilizationEndtDate, "2050-12-31");
		// Verify Prerequisites drop down exits
		CheckElementPresent(dd_Prerequisites, true);
		// Verify Add new Prerequisites button exist & enabled
		CheckElementEnabled(btn_AddNewPrerequisites, true);
		// Verify the table for existing Prerequisites items exist
		CheckElementPresent(tbl_ExistingPrerequisites, true);
		// Verify Purchase Option drop down exits
		CheckElementPresent(dd_PurchaseOption, true);
		// Verify Add new Purchase Option button exist & enabled
		CheckElementEnabled(btn_AddNewPurchaseOptions, true);
		// Verify the table for existing Purchase Option items exist
		CheckElementPresent(tbl_ExistingPurchaseOptions, true);

		WriteToReport("=======End of bf_VeriyAddNewChannelUI=========");
	}

	// Click on select key drop down
	public void bf_ClickSelectKeyDropdown() {

		WriteToReport("=======Start of bf_ClickSelectKeyDropdown========");
		// Click on the button
		Click(dd_SelectKey);

		WriteToReport("=======End of bf_ClickSelectKeyDropdown=========");
	}

	// Click on status drop down
	public void bf_ClickStausDropdown() {

		WriteToReport("=======Start of bf_ClickSelectKeyDropdown========");
		// Click on the button
		Click(btn_Status);

		WriteToReport("=======End of bf_ClickSelectKeyDropdown=========");
	}

}
