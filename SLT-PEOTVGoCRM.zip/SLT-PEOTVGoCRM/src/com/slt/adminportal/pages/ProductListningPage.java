package com.slt.adminportal.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class ProductListningPage extends TestBase_Commands {

	private static By lbl_UserName = By.xpath("//button[text()='LOG OUT']/preceding::h4");
	private static By btn_LogOut = By.xpath("//button[text()='LOG OUT']");
	private static By lbl_ProductName = By.xpath("//button[text()='Add New']/preceding::h4[1]");
	private static By btn_AddNew = By.xpath("//button[text()='Add New']");
	private static By btn_BulkActions = By.xpath("//button[text()='Add New']/following::button[1]");
	private static By opt_Inactive = By.xpath("//a[contains(text(),'Inactive')]");
	private static By opt_Active = By.xpath("//a[contains(text(),'Active')]");
	private static By opt_Delete = By.xpath("//a[contains(text(),'Delete')]");
	private static By btn_Apply = By.xpath("//button[text()='Apply']");
	private static By tf_Search = By.xpath("//input[@placeholder='Search By Title']");
	private static By btn_FilterByCategory = By.xpath("//button[contains(text(),'Filter')]");
	private static By opt_FilterByCategory = By.xpath("//div[@title='Filter by Category']/a");
	private static By lbl_Thumbnail = By.xpath("//th[text()='Thumbnail']");
	private static By lbl_Title = By.xpath("//th[text()='Title']");
	private static By lbl_Description = By.xpath("//th[text()='Description']");
	private static By lbl_Category = By.xpath("//th[text()='Category']");
	private static By lbl_ChannelNumber = By.xpath("//th[text()='Channel Number']");
	private static By chk_AllCheckboxesOfProduct = By.xpath("//input[@type='checkbox']");
	private static By lst_AllProductNames = By.xpath("//td[@class='channel-attributes channel-name']");
	private static By btn_View = By.xpath("//h2[text()='View']");
	private static By btn_Edit = By.xpath("//h2[text()='Edit']");
	private static By btn_Duplicate = By.xpath("//h2[text()='Duplicate']");
	private static By btn_Inactive = By.xpath("//h2[text()='Inactive']");
	private static By btn_Delete = By.xpath("//h2[text()='Delete']");
	private static By btn_Active = By.xpath("//h2[text()='Active']");
	private static By val_Title = By.xpath("//td[@class='channel-attributes channel-name']");
	private static By val_Description = By.xpath("//td[@class='channel-description']");
	private static By val_ChannelCategory = By.xpath("//td[@class='channel-attributes'][1]");
	private static By val_ChannelNumber = By.xpath("//td[@class='channel-attributes'][2]");

	public ProductListningPage(WebDriver driver) {
		this.driver = driver;

	}

	// Verify the header in product listing page
	public void bf_VeriyHeaderOfProductListningPage(String prm_ProductName) {

		WriteToReport("=======Start of bf_VeriyHeaderOfProductListningPage========");
		
		VerifyHeader(lbl_ProductName, prm_ProductName);

		WriteToReport("=======End of bf_VeriyHeaderOfProductListningPage=========");
	}

	// Verify the Login page UI
	public void bf_VeriyChannlListingUI(String prm_ProductName) {

		WriteToReport("=======Start of bf_VeriyChannlListingUI=============");
		// Verify that label user name field exists
		VerifyText(lbl_ProductName, prm_ProductName);
		// Verify that label user name field exists
		CheckElementPresent(lbl_UserName, true);
		// Verify that button LogOut exists in the page
		CheckElementPresent(btn_LogOut, true);
		// Verify that button Add New exists in the page
		CheckElementPresent(btn_AddNew, true);
		// Verify that Bulk Action drop down exists in the page
		CheckElementPresent(btn_BulkActions, true);
		// Verify Inactive option exist in the bulk Active drop down
		//CheckElementPresent(opt_Active, true);
		// Verify Inactive option exist in the bulk inactive drop down
		CheckElementPresent(opt_Inactive, true);
		// Verify Delete option exist in the bulk inactive drop down
		CheckElementPresent(opt_Delete, true);
		// Verify that button Apply exists in the page
		CheckElementPresent(btn_Apply, true);
		// Verify that text field search exists in the page
		CheckElementPresent(tf_Search, true);
		// Verify the place holder of search
		VerifyPlaceHolder(tf_Search, "Search By Title");
		// Verify that Filter by Category drop down exists in the page
		CheckElementPresent(btn_FilterByCategory, true);
		// Verify Filter by Category drop down options
		
		// Verify that label Thumbnail exists in the page
		CheckElementPresent(lbl_Thumbnail, true);
		// Verify that label Title exists in the page
		CheckElementPresent(lbl_Title, true);
		// Verify that label Description exists in the page
		CheckElementPresent(lbl_Description, true);
		// Verify that label Category exists in the page
		CheckElementPresent(lbl_Category, true);
		// Verify that label Utilize Period exists in the page
		CheckElementPresent(lbl_ChannelNumber, true);
		/*
		// Verify that button View exists in the page
		CheckElementPresent(btn_View, true);
		// Verify that button Edit exists in the page
		CheckElementPresent(btn_Edit, true);
		// Verify that button duplicate exists in the page
		CheckElementPresent(btn_Duplicate, true);
		// Verify that button inactive exists in the page
		CheckElementPresent(btn_Inactive, true);
		// Verify that button Delete exists in the page
		CheckElementPresent(btn_Delete, true);
		// Verify the color of delete button
		String colourDeleteButton = GetFontColur(btn_Delete);
		if (colourDeleteButton.equals("#dc3545")) {
			WriteToReport("Delte button showing correct colour code as " + colourDeleteButton + "and it is Red");
		} else {
			FailTest("Delet button not showing in Red colour");
		}
		*/

		WriteToReport("=======End of bf_VeriyChannlListingUI=============");
	}

	// Click Add New button to add a new product
	public void bf_ClickAddNewButton() {

		WriteToReport("=======Start of bf_ClickAddNewButton========");
		// Click Add New Button
		Click(btn_AddNew);

		WriteToReport("=======End of bf_ClickAddNewButton=========");
	}

	// Select a value from Bulk Action dropdown
	public void bf_SelectFromBulkActions(String prm_option) {

		WriteToReport("=======Start of bf_SelectFromBulkActions========");
		// Click Add New Button
		SelectValueSelectByVisibleText(btn_BulkActions, prm_option);

		WriteToReport("=======End of bf_SelectFromBulkActions=========");
	}

	// Click Add New button to add a new product
	public void bf_ClickApplyButton() {

		WriteToReport("=======Start of bf_ClickApplyButton========");
		// Click Add New Button
		Click(btn_AddNew);

		WriteToReport("=======End of bf_ClickApplyButton=========");
	}

	// Click Add New button to add a new product
	public int bf_GetProductCount() {

		WriteToReport("=======Start of bf_GetProductCount========");
		//
		int productCount = getCount(lst_AllProductNames);
		if (productCount == 0) {
			WriteToReport("No record available for the product");
		} else {
			WriteToReport("Showing " + productCount + " for the product");
		}

		WriteToReport("=======End of bf_GetProductCount=========");
		return productCount;
	}

	// Search products
	public void bf_SearchProductsAndVerifyResults(String prm_SearchText) {
		// Get the matching count before searching
		int matchCountBeforeSearch = FindMatchCount(lst_AllProductNames, prm_SearchText);
		// Type a text to search
		Type(tf_Search, prm_SearchText);
		// Get the count matching count after result
		int matchCountAfterSeach = getCount(lst_AllProductNames);
		if (matchCountBeforeSearch == matchCountAfterSeach) {
			WriteToReport("Result count match before & After Search");
		} else {
			FailTest("Result count not match before & After Search. Expected " + matchCountBeforeSearch + " but Found "
					+ matchCountAfterSeach);
		}
		// Verify that unmatched result not returned after search
		VerifyMatchText(lst_AllProductNames, prm_SearchText);
		WriteToReport("=======End of bf_SearchProductsAndVerifyResult=========");

	}

	// Search a product
	public void bf_SearchPruducts(String prm_SearchText) {
		// Type a text to search
		Type(tf_Search, prm_SearchText);
	}

	// Click on a product
	public void bf_ClickedOnProduct(String prm_ProductName) {
		ClickedOnSelectedItem(lst_AllProductNames, prm_ProductName);
	}

	// Filter By Category & Verify result
	public void bf_FilterByCategoryAndVerifyResults(String prm_filterByCategory) {

		WriteToReport("=======Start of bf_VerifySearchResults========");
		// Get the total number of matching count before fitering
		int countBeforeFilter = FindMatchCount(lst_AllProductNames, prm_filterByCategory);

		// Select a value from Filter by Category dropdown
		SelectValueSelectByVisibleText(btn_FilterByCategory, prm_filterByCategory);
		// Get the total number of matching count before fitering
		int countAfterFilter = FindMatchCount(lst_AllProductNames, prm_filterByCategory);
		if (countBeforeFilter == countAfterFilter) {
			WriteToReport("Result count match before & After Filering");
		} else {
			FailTest("Result count not match before & After Search. Expected " + countBeforeFilter + " but Found "
					+ countAfterFilter);
		}
		// Verify that unmatched result not returned after filtering
		VerifyMatchText(lst_AllProductNames, prm_filterByCategory);

		WriteToReport("=======End of bf_VerifySearchResults=========");
	}

	// Filter By FilterByPerdiod & Verify result
	public void bf_FilterByPediodAndVerifyResults(String prm_filterByPeriod) {

		WriteToReport("=======Start of bf_VerifySearchResults========");
		// Get the total number of matching count before filtering
		int countBeforeFilter = FindMatchCount(lst_AllProductNames, prm_filterByPeriod);

		// Select a value from Filter by Category drop down
		SelectValueSelectByVisibleText(btn_FilterByCategory, prm_filterByPeriod);
		// Get the total number of matching count before filtering
		int countAfterFilter = FindMatchCount(lst_AllProductNames, prm_filterByPeriod);
		if (countBeforeFilter == countAfterFilter) {
			WriteToReport("Result count match before & After Filering");
		} else {
			FailTest("Result count not match before & After Search. Expected " + countBeforeFilter + " but Found "
					+ countAfterFilter);
		}
		// Verify that unmatched result not returned after filtering
		VerifyMatchText(lst_AllProductNames, prm_filterByPeriod);

		WriteToReport("=======End of bf_VerifySearchResults=========");
	}

	// Verify the Filter by Period after adding based on Utilize Start Date &
	// Utilize End Date
	public void bf_VeriyProductDetailsInTabel() {

		WriteToReport("=======Start of bf_VerifySearchResults========");

		WriteToReport("=======End of bf_VerifySearchResults=========");
	}

}
