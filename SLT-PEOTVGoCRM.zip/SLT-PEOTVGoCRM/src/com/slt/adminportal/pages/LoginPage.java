package com.slt.adminportal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class LoginPage extends TestBase_Commands {

	private static By lbl_LogIn = By.xpath("//h3[contains(text(),'Log')]");
	private static By lbl_UserName = By.xpath("//h4[contains(text(),'Username')]");
	private static By tf_UserName = By.name("username");
	private static By lbl_Password = By.xpath("//h4[contains(text(),'Password')]");
	private static By tf_Password = By.name("password");
	private static By btn_login = By.xpath("//span[normalize-space(text())='LOG IN']");
	private static By msg_UserName = By.xpath("//input[@name='username']/following::div[1]");
	private static By msg_Password = By.xpath("//input[@name='password']/following::div[1]");
	private static By msg_IncorrectUsernameAndPassword = By.xpath("//div[contains(text(),'Invalid')]");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// Verify the Login page UI
	public void bf_VeriyfLoginUI() {

		WriteToReport("=======Start of bf_VeriyfLoginUI=============");
		// Open the browser
		Open("http://172.17.250.86:8080");
		// Verify that Log In name field
		VerifyText(lbl_LogIn, "Log In");
		// Verify that user name text filed exists in the page
		// Verify that label user name field
		VerifyText(lbl_UserName, "Username");
		// Verify that user name text filed exists in the page
		CheckElementPresent(tf_UserName, true);
		// Verify that label password field
		VerifyText(lbl_Password, "Password");
		// Verify that password text filed exists in the page
		CheckElementPresent(tf_Password, true);
		// Verify that button login exists in the page
		CheckElementPresent(btn_login, true);
		WriteToReport("=======End of bf_VeriyfLoginUI=============");
	}

	// Login to admin portal
	public void bf_LoginToAdminPortal(String prm_username, String prm_password) {

		WriteToReport("=======Start of bf_Login=============");
		// Open the browser
		Open("http://172.17.250.86:8080");
		// Enter User name
		Type(tf_UserName, prm_username);
		// Enter Password
		Type(tf_Password, prm_password);
		// Click Login
		Click(btn_login);

		WriteToReport("=======End of bf_Login=============");
	}

	// Verify validation message of login page
	public void bf_VerifyMessagesWhenLoingIsInvalid(String prm_Username, String prm_Password,
			String prm_IncorrectUsername, String prm_incorrectPassword, String prm_msgUsername, String prm_msgPassword,
			String msgUnameAndPassword) {

		WriteToReport("=======Start of bf_VerifyMessagesWhenLoingIsInvalid========");
		// Verify validation message when user not enter password
		bf_LoginToAdminPortal(prm_Username, "");
		VerifyText(msg_Password, prm_msgPassword);
		// Verify validation message when user not enter the user name
		Refresh();
		bf_LoginToAdminPortal("", prm_Username);
		VerifyText(msg_UserName, prm_msgUsername);
		// Verify validation message when user not enter both user name & password
		bf_LoginToAdminPortal("", "");
		VerifyText(msg_UserName, prm_msgUsername);
		VerifyText(msg_Password, prm_msgPassword);
		// Verify the validation message when user name is incorrect
		Refresh();
		bf_LoginToAdminPortal(prm_IncorrectUsername, prm_Password);
		VerifyText(msg_IncorrectUsernameAndPassword, msgUnameAndPassword);
		// Verify the validation message when password is incorrect
		Refresh();
		bf_LoginToAdminPortal(prm_Username, prm_incorrectPassword);
		VerifyText(msg_IncorrectUsernameAndPassword, msgUnameAndPassword);

		WriteToReport("=======End of bf_VerifyMessagesWhenLoingIsInvalid========");
	}

	// Store User name
	public String bf_StoreUsername() {

		WriteToReport("=======Start of bf_StoreUsername=============");
		StoreValue(tf_UserName);
		WriteToReport("=======End of bf_StoreUsername=============");
		return StoreValue(tf_UserName);
	}

}
