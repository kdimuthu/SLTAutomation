package com.slt.adminportal.pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import Utility.TestBase_Commands;

public class ChannelPage extends TestBase_Commands {

	private By lbl_AddNewChannel = By.xpath("");
	private By tf_ChannelName = By.xpath("");
	private By tf_ExternalRefNum = By.xpath("");
	private By icn_ExternalRefNum = By.xpath("");
	private By tf_DownstreamRefNum = By.xpath("");
	private By icn_DownstreamRefNum = By.xpath("");
	private By tf_ChannelNumber = By.xpath("");
	private By tf_ChannelDescription = By.xpath("");
	private By lbl_1000CharactorRemain = By.xpath("");
	private By img_Logo = By.xpath("");
	private By lbl_Logo = By.xpath("");
	private By lbl_NoFileSelected = By.xpath("");
	private By btn_AddImage = By.xpath("");
	private By btn_SelectCategory = By.xpath("");
	private By chk_ForeignVariety = By.xpath("");
	private By chk_NewsBusiness = By.xpath("");
	private By chk_Infotainment = By.xpath("");
	private By chk_LocalVariety = By.xpath("");
	private By chk_Kids = By.xpath("");
	private By chk_Movie = By.xpath("");
	private By chk_LearningAndEducationl = By.xpath("");
	private By chk_Religious = By.xpath("");
	private By chk_Tamil = By.xpath("");
	private By chk_TravelAndLiving = By.xpath("");
	private By chk_Music = By.xpath("");
	private By chk_LocalMusic = By.xpath("");
	private By chk_Sports = By.xpath("");
	private By chk_AllCategories = By.xpath("");
	private By tf_PGRating = By.xpath("");
	private By dd_AllowedRegions = By.xpath("");
	private By btn_AllowedRegions = By.xpath("");
	private By cal_PurchaseStartDate = By.xpath("");
	private By cal_PurchaseEndDate = By.xpath("");
	private By cal_UtiPeriodStartDate = By.xpath("");
	private By cal_UtiPeriodEndDate = By.xpath("");
	private By dd_Prerequiests = By.xpath("");
	private By btn_Prerequiests = By.xpath("");
	private By icn_Prerequiests = By.xpath("");
	private By chk_AvailabilityStandalone = By.xpath("");
	private By chk_AvailabilityPackage = By.xpath("");
	private By dd_PurchaseOption = By.xpath("");
	private By btn_PurchaseOption = By.xpath("");
	private By icn_PurchaseOption = By.xpath("");
	private By btn_AddChannel = By.xpath("");
	private By lbl_ViewChannel = By.xpath("");

	public ChannelPage(WebDriver driver) {
		this.driver = driver;
	}

	// Verify the header of add new channel
	public void bf_VeriyHeaderOfAddNewChannel() {

		WriteToReport("=======Start of bf_VeriyHeaderOfAddNewChannel=========");
		// Verify the header of Add new channel
		VerifyHeader(lbl_AddNewChannel, "");

		WriteToReport("=======End of bf_VeriyHeaderOfAddNewChannel=========");
	}

	// Verify Add New Channel UI
	public void bf_VerifyAddNewChannelUI(String prm_username, String prm_password) {

		WriteToReport("=======Start of bf_VerifyAddNewChannelUI==========");
		// Verify Channel Name field exists
		CheckElementPresent(tf_ChannelName,true);
		// Verify External Reference Number field exists
		CheckElementPresent(tf_ExternalRefNum,true);
		// Verify External Reference Number help icon exists
		CheckElementPresent(icn_ExternalRefNum,true);
		// Verify Downstream Reference Number field exists
		CheckElementPresent(tf_DownstreamRefNum,true);
		// Verify Downstream Reference Number help icon exists
		CheckElementPresent(icn_DownstreamRefNum,true);
		// Verify Channel Number field exists
		CheckElementPresent(tf_ChannelNumber,true);
		// Verify Channel Description field exists
		CheckElementPresent(tf_ChannelDescription,true);
		// Verify 1000 character remain exists
		CheckElementPresent(lbl_1000CharactorRemain,true);
		// Verify Logo label exists
		CheckElementPresent(lbl_Logo,true);
		// Verify Logo label exists
		CheckElementPresent(lbl_NoFileSelected,true);
		// Verify button Select Category exists
		CheckElementPresent(btn_SelectCategory,true);
		// Verify checkbox Foreign Variety exists
		CheckElementPresent(chk_ForeignVariety,true);
		// Verify checkbox News/Business exists
		CheckElementPresent(chk_NewsBusiness,true);
		// Verify checkbox News/Business exists
		CheckElementPresent(chk_Infotainment,true);
		// Verify checkbox News/Business exists
		CheckElementPresent(chk_LocalVariety,true);
		// Verify checkbox Kids exists
		CheckElementPresent(chk_Kids,true);
		// Verify checkbox Movie exists
		CheckElementPresent(chk_Movie,true);
		// Verify checkbox Learning And Educationl exists
		CheckElementPresent(chk_LearningAndEducationl,true);
		// Verify checkbox Religious exists
		CheckElementPresent(chk_Religious,true);
		// Verify checkbox Tamil exists
		CheckElementPresent(chk_Tamil,true);
		// Verify checkbox Tamil exists
		CheckElementPresent(chk_TravelAndLiving,true);
		// Verify checkbox Music exists
		CheckElementPresent(chk_Music,true);
		// Verify checkbox Local Music exists
		CheckElementPresent(chk_LocalMusic,true);
		// Verify checkbox Local Music exists
		CheckElementPresent(chk_Sports,true);
		// Verify PG Rating field exists
		CheckElementPresent(tf_PGRating,true);
		// Verify Allowed Region drop down exists
		CheckElementPresent(dd_AllowedRegions,true);
		// Verify the default value of Allowed Region
		VerifySelectedOption(dd_AllowedRegions, "");
		// Verify Allowed Region button exists
		CheckElementPresent(btn_AllowedRegions,true);
		// Verify calendar Purchase Start Date exists
		CheckElementPresent(cal_PurchaseStartDate,true);
		// Verify default value of Purchase Start Date

		// Verify calendar Purchase Start Date exists
		CheckElementPresent(cal_PurchaseEndDate,true);

		// Verify default value of Purchase End Date

		// Verify calendar utilise Period Start Date exists
		CheckElementPresent(cal_UtiPeriodStartDate,true);

		// Verify default value of Utilise Period Start Date
		// Verify calendar utilise Period End Date exists
		CheckElementPresent(cal_UtiPeriodEndDate,true);

		// Verify default value of Utilise Period End Date

		// Verify Prerequisites drop down exists
		CheckElementPresent(dd_Prerequiests,true);
		// Verify default value of drop down
		VerifySelectedOption(dd_Prerequiests, "");
		// Verify Prerequisites button exists
		CheckElementPresent(btn_Prerequiests,true);
		// Verify help icon for Prerequisites exists
		CheckElementPresent(icn_Prerequiests,true);
		// Verify checkbox Standalone exists
		CheckElementPresent(chk_AvailabilityStandalone,true);
		// Verify checkbox Package exists
		CheckElementPresent(chk_AvailabilityPackage,true);
		// Verify Purchase Option drop down exists
		CheckElementPresent(dd_PurchaseOption,true);
		// Verify default value of dd_Purchase Option drop down
		VerifySelectedOption(dd_PurchaseOption, "");
		// Verify Purchase option button exists
		CheckElementPresent(btn_PurchaseOption,true);
		// Verify help icon for Prerequisites exists
		CheckElementPresent(icn_PurchaseOption,true);
		// Verify add channel button
		CheckElementPresent(btn_AddChannel,true);

		WriteToReport("=======End of bf_VerifyAddNewChannelUI=========");
	}

	// Filling Add channel details
	public void bf_FillAddChannels(String prm_ChannelName, String prm_ExRefNum, String prm_Dw_Ref_Num,
			String prm_ChannelNum, String prm_ChannelDes, String prm_ImageName, String prm_SelectCategory,
			String prm_PgRating, String prm_AllowedRegion, String prm_Requistes, String prm_Avialability,
			String prm_PurOption) {

		WriteToReport("=======Start of bf_FillAddChannels========");
		// Enter Channel name
		Type(tf_ChannelName, prm_ChannelName);
		// Enter External reference number
		Type(tf_ExternalRefNum, prm_ExRefNum);
		// Enter Downstream reference number
		Type(tf_DownstreamRefNum, prm_Dw_Ref_Num);
		// Enter Channel Number
		Type(tf_ChannelNumber, prm_ChannelNum);
		// Enter Description
		Type(tf_ChannelDescription, prm_ChannelDes);
		// Click Add image button
		Click(btn_AddImage);
		// Upload an image
		FileUpload(prm_ImageName);
		// Select a category
		bf_SelectCategory(prm_SelectCategory);
		// Enter PG Rating
		Type(tf_PGRating, prm_PgRating);
		// Select a option from Allowed region dropdown
		SelectValueSelectByVisibleText(dd_AllowedRegions, prm_AllowedRegion);
		// Select Purchase Start Date

		// Select Purchase End Date

		// Select a utilise period start date

		// Select a utilise period end date

		// Selecc an option from dropdown prerequisites
		SelectValueSelectByVisibleText(dd_Prerequiests, prm_Requistes);
		if (prm_Avialability.equals("Standalone")) {
			Click(chk_AvailabilityStandalone);
		} else if (prm_Avialability.equals("NewsBusiness")) {
			Click(chk_NewsBusiness);
		} else if (prm_Avialability.equals("both")) {
			Click(chk_AvailabilityStandalone);

		}

		// Select an option from Purchase option table
		SelectValueSelectByVisibleText(dd_PurchaseOption, prm_PurOption);

		WriteToReport("=======End of bf_FillAddChannels========");
	}

	// Select Categories

	public void bf_SelectCategory(String prm_Category) {

		WriteToReport("=======Start of bf_SelectCategory=========");

		if (prm_Category.equals("Foreign Variety")) {
			Click(chk_ForeignVariety);
		} else if (prm_Category.equals("NewsBusiness")) {
			Click(chk_NewsBusiness);
		} else if (prm_Category.equals("Infotainment")) {
			Click(chk_Infotainment);
		} else if (prm_Category.equals("Local Variety")) {
			Click(chk_LocalVariety);
		} else if (prm_Category.equals("Kids")) {
			Click(chk_Kids);
		} else if (prm_Category.equals("Movie")) {
			Click(chk_Movie);
		} else if (prm_Category.equals("Learning And Educationl")) {
			Click(chk_LearningAndEducationl);
		} else if (prm_Category.equals("Religious")) {
			Click(chk_Religious);
		} else if (prm_Category.equals("Tamil")) {
			Click(chk_Tamil);
		} else if (prm_Category.equals("TravelAndLiving")) {
			Click(chk_TravelAndLiving);
		} else if (prm_Category.equals("Music")) {
			Click(chk_Music);
		} else if (prm_Category.equals("Local Music")) {
			Click(chk_LocalMusic);
		} else if (prm_Category.equals("Sports")) {
			Click(chk_Sports);
		} else if (prm_Category.equals("multipe")) {
			Click(chk_Sports);
		} else if (prm_Category.equals("All")) {
			SelectAllCheckBoxes(chk_AllCategories);
			Click(chk_NewsBusiness);
		}

		WriteToReport("=======End of bf_SelectCategory=========");
	}

	// Click on the Add Channels button
	public void bf_ClickAddChannelbutton() {

		WriteToReport("=======Start of bf_ClickAddChannelbutton=======");
		Click(btn_AddChannel);

		WriteToReport("=======End of bf_ClickAddChannelbutton=======");
	}

	// Verify Validation messages of mandatory fields in Add channel UI
	public void bf_VeriyValidationMessagesOfAddChannelUI() {

		WriteToReport("=======Start of bf_VeriyValidationMessagesOfAddChannelUI=======");

		WriteToReport("=======End of bf_VeriyValidationMessagesOfAddChannelUI=======");
	}

	// Verify the help icons of Add channels UI
	public void bf_VeriyHelpIconInAddChannelsUI() {

		WriteToReport("=======Start of bf_VeriyHelpIconInAddChannelsUI=======");

		WriteToReport("=======End of bf_VeriyHelpIconInAddChannelsUI=======");

	}

	// Store Channel Name
	public String bf_StoreChannelName() {

		WriteToReport("=======Start of bf_VeriyHelpIconInAddChannelsUI=======");

		String channelName = StoreValue(tf_ChannelName);

		WriteToReport("=======End of bf_VeriyHelpIconInAddChannelsUI=======");
		return channelName;
	}

	// Store Enter information while adding channels
	public String[] bf_StoreChannelCreationInfomation() {

		WriteToReport("=======Start of bf_StoreChannelCreationInfomation=======");
		// Store Channel name
		String channelName = StoreValue(tf_ChannelName);

		// Store External Reference Number
		String ExRefNumber = StoreValue(tf_ExternalRefNum);

		// Store Downstream Reference Number
		String DownStreamRefNumber = StoreValue(tf_DownstreamRefNum);

		// Store Channel number
		String channelNumber = StoreValue(tf_ChannelNumber);

		// Store Channel Description
		String channelDescription = StoreValue(tf_ChannelDescription);

		// Store image name
		String imageName = "";

		// Store check box status
		Boolean CatForiegnVar = IsElementSelected(chk_ForeignVariety);
		String chkForiegnVar = String.valueOf(CatForiegnVar);

		Boolean CatNewsBusiness = IsElementSelected(chk_NewsBusiness);
		String chkNewsBusiness = String.valueOf(CatNewsBusiness);

		Boolean CatInfotainment = IsElementSelected(chk_Infotainment);
		String chkkInfotainment = String.valueOf(CatInfotainment);

		Boolean CatLocalVariety = IsElementSelected(chk_LocalVariety);
		String chkLocalVariety = String.valueOf(CatLocalVariety);

		Boolean CatKids = IsElementSelected(chk_Kids);
		String chkKids = String.valueOf(CatKids);

		Boolean CatMovie = IsElementSelected(chk_Movie);
		String chkMovie = String.valueOf(CatMovie);

		Boolean CatLearningAndEducationl = IsElementSelected(chk_LearningAndEducationl);
		String chkLearningAndEducationl = String.valueOf(CatLearningAndEducationl);

		Boolean CatReligious = IsElementSelected(chk_Religious);
		String chkReligious = String.valueOf(CatReligious);

		Boolean CatTamil = IsElementSelected(chk_Tamil);
		String chkTamil = String.valueOf(CatTamil);

		Boolean CatTravelAndLiving = IsElementSelected(chk_TravelAndLiving);
		String chkTravelAndLiving = String.valueOf(CatTravelAndLiving);

		Boolean CatMusic = IsElementSelected(chk_Music);
		String chkMusic = String.valueOf(CatMusic);

		Boolean CatLocalMusic = IsElementSelected(chk_LocalMusic);
		String chkLocalMusic = String.valueOf(CatLocalMusic);

		Boolean catSports = IsElementSelected(chk_Sports);
		String chkSports = String.valueOf(catSports);

		// Store PG Rating
		String PGRating = StoreValue(tf_PGRating);

		// Store Allowed Regionds
		String AllowedRegiod = StoreSelectedOption(dd_AllowedRegions);

		// Store Purchase Start Date
		String purStartDate = "";

		// Store Purchase End Date
		String purEndDate = "";

		// Store Utilise Period Start Date
		String UtilisePeriodStartDate = "";

		// Store Utilise Period End Date

		String UtilisePeriodEndDate = "";

		// Store selected option in prerequistes dropdown
		String Prerequisites = StoreSelectedOption(dd_AllowedRegions);

		// Store Availability check box
		Boolean AvaStandalone = IsElementSelected(chk_AvailabilityStandalone);
		String chkAvailabilityStandalone = String.valueOf(AvaStandalone);

		Boolean AvailabilityPackage = IsElementSelected(chk_AvailabilityPackage);
		String chkAvailabilityPackage = String.valueOf(AvailabilityPackage);

		// Store selected option in Purchase Option dropdown
		String PurchaseOption = StoreSelectedOption(dd_AllowedRegions);

		String[] ChannelInfo = { channelName, ExRefNumber, DownStreamRefNumber, channelNumber, channelDescription,
				imageName, chkForiegnVar, chkNewsBusiness, chkkInfotainment, chkLocalVariety, chkKids, chkMovie,
				chkLearningAndEducationl, chkReligious, chkTamil, chkTravelAndLiving, chkMusic, chkLocalMusic,
				chkSports, PGRating, AllowedRegiod, purStartDate, purEndDate, UtilisePeriodStartDate,
				UtilisePeriodEndDate, Prerequisites, chkAvailabilityStandalone, chkAvailabilityPackage,
				PurchaseOption };
		WriteToReport("=======End of bf_StoreChannelCreationInfomation=======");
		return ChannelInfo;

	}

	// Verify the added channel information
	public void bf_verifyAddedChannelinViewChannelUI(String[] prm_BeforeAdding, String[] prm_AfterAdding) {
		WriteToReport("=======Start of bf_verifyAddedChannelinViewChannelUI=========");
		// Verify the channel information
		CompareTowArray(prm_BeforeAdding, prm_AfterAdding);
		WriteToReport("=======End of bf_verifyAddedChannelinViewChannelUI=========");
	}

	// Verify the header of add new channel
	public void bf_VeriyHeaderOfViewChannel() {

		WriteToReport("=======Start of bf_VeriyHeaderOfViewChannel=========");
		// Verify the header of Add new channel
		VerifyHeader(lbl_AddNewChannel, "");

		WriteToReport("=======End of bf_VeriyHeaderOfViewChannel=========");
	}

	// Verify the view channel UI
	public void bf_VeriyViewChannelUI() {

		WriteToReport("=======Start of bf_VeriyViewChannelUI=========");
		// Verify that channel name is read only

		 // Verify that External Ref
		
		// Verify Num is read only 		 

		WriteToReport("=======End of bf_VeriyViewChannelUI=========");
	}

}
